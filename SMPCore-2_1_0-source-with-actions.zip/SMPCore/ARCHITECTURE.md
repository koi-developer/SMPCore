# SMPCore 2.1.0 Architecture

## Runtime boundaries

```text
Paper / Bukkit API
       |
       +-- commands/MenuCommand
       |        `-- SMPCore.onCommand -> permission check -> /menu
       |
       +-- events/InventoryMenuListener
       +-- events/ChatInputListener
       +-- events/QuestGameplayListener
       `-- events/PlayerLifecycleListener
                `-- existing event workflows in SMPCore

SMPCore (JavaPlugin lifecycle)
       |
       +-- menu/MenuManager
       +-- player/PlayerManager
       +-- economy/EconomyManager
       +-- quest/QuestManager
       |       +-- quest configuration views
       |       +-- objective progress
       |       `-- reward claim via EconomyManager persistence
       +-- teleport/TeleportManager
       |       +-- homes.yml persistence
       |       +-- warps.yml persistence
       |       `-- destination and world-border validation
       +-- config/ConfigManager
       `-- storage/StorageManager
                +-- BackupManager
                +-- AuditLogger
                `-- AtomicFileWriter
```

## Ownership

- `SMPCore` owns the Paper plugin lifecycle, GUI page construction/click routing, chat prompt lifecycle, TPA state and scoreboard state.
- `MenuCommand` is the `/menu` Bukkit adapter. The permission check and menu launch remain in `SMPCore`.
- Listener classes only bind Paper/Bukkit events to the existing workflow methods.
- `EventManager` owns listener instances and unregisters each registered listener during plugin disable.
- `QuestManager` owns quest definitions, enabled quest selection, progress updates, ready counts and claim state. A claim updates the wallet and `claimed` flag using one `EconomyManager` persistence operation.
- `TeleportManager` owns home/warp YAML paths, create/delete rollback, location deserialization validation and synchronous teleport checks.
- `EconomyManager`, `QuestManager`, `TeleportManager` and the YAML-backed managers are server-thread services. They must not be called from arbitrary asynchronous tasks.

## Thread model

`AsyncChatEvent` may execute asynchronously for player-originated network chat. The chat adapter delegates to `SMPCore.onChatInput`, which uses concurrent input-state collections, cancels the input event, extracts plain text, and schedules Bukkit/game-state mutations with the server scheduler. Do not move YAML writes, inventory operations, teleports, or other Bukkit mutations into the asynchronous event path.

Inventory, block, entity, join, quit, command and scheduled workflows are executed on the server thread under normal Paper event/scheduler behavior.

## Persistent data

The data-file layout remains unchanged:

- `config.yml`: plugin configuration and defaults.
- `players.yml`: wallets, player settings, statistics, quest progress, reward dates and kit cooldowns.
- `homes.yml`: player homes.
- `warps.yml`: named server destinations.
- `market.yml`: fixed-price listings and serialized item data.
- `backups/`: timestamped SMPCore data snapshots.
- `logs/audit.log`: bounded audit log with one rotated segment.

No data migration is intended from 2.0.0 to 2.1.0. Always stop the server and back up `plugins/SMPCore/` before replacing a production JAR.

## Remaining extraction work

GUI page builders, click routing, market workflows, most player lifecycle handling, TPA state and scoreboard state still live in `SMPCore.java`. The current release extracts quest and teleport domain workflows but is not yet a complete domain/service architecture. Future releases can move these incrementally with focused tests and data-compatibility checks.
