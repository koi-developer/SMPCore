# SMPCore 2.1.0

A GUI-first Minecraft Java SMP core for **Paper 1.21.11 / Java 21**. Players use `/menu` (alias `/smpmenu`) as the central hub. No additional player-facing commands are required.

## 2.1.0 quest and teleport services

- Extracted quest configuration lookup, objective progress, ready-state counting and reward claims into `quest/QuestManager`.
- Quest rewards and the claimed flag are committed in one `players.yml` save through `EconomyManager`; a failed save restores the in-memory YAML snapshot and leaves the claim available.
- Quest keys are restricted to safe path segments; objective progress is capped at its target without arithmetic overflow.
- Extracted home/warp reads, writes, create/delete transactions, location validation and teleport checks into `teleport/TeleportManager`.
- Home/warp create and delete operations use a shared save-and-rollback path; rollback persistence failures are logged.
- Stored destinations with missing worlds or non-finite coordinates/rotations are rejected. Teleport attempts check the destination world border and preserve cancellation/failure results.
- Rebuilds `QuestManager` after config reload so it never retains the previous configuration instance.
- Added focused manager smoke tests using isolated API stubs; these test service logic but are not Paper integration tests.

## 2.0.0 modular event and command architecture

- Added `ConfigManager` for defaults and value validation, `EconomyManager` for wallet persistence and rollback, and `StorageManager` as the backup/audit facade.
- Added `AtomicFileWriter` for unique temporary files, explicit file flush, atomic replacement where supported, and cleanup.
- `SMPCore` delegates configuration, wallet, and backup/audit orchestration to focused managers. Bukkit command and event entry points now live in dedicated adapters under `commands/` and `events/`; the main class retains the gameplay workflows that those adapters invoke.
- Creates timestamped snapshots of `config.yml`, `homes.yml`, `warps.yml`, `players.yml`, `market.yml` and available audit log segments.
- Automatic backups are enabled by default every six hours; the newest ten snapshots are retained.
- Admin Panel includes a manual **Create Storage Backup** action. It saves live YAML data first and refuses to snapshot if any data file cannot be saved.
- Economy transfers, daily rewards, quest claims, shop purchases, kit cooldowns and player preference toggles now check the relevant save result before confirming success.
- Shop and kit deliveries restore the pre-action inventory if their required data write fails. Wallet changes restore the previous in-memory YAML snapshot on a failed write. Home/warp create-delete actions also retain the previous entry when persistence fails.
- Added a bounded `logs/audit.log` with rotation for player transfers, shop/market transactions, kit and quest rewards, daily claims and admin wallet edits.
- Reload Configuration now refreshes both scoreboard and automatic-backup schedules.

The backup task runs on the server thread because Bukkit YAML state is not safe to serialize from an asynchronous task. Backups are point-in-time copies of the plugin YAML files, not backups of the Minecraft world or player region data. Copy the entire server folder and world data separately for full-server disaster recovery.

## 1.6.0 reliability improvements

- Player Market purchases now validate the listing price and item before processing. Both market and wallet files are saved before the item is delivered; failed saves trigger a snapshot rollback.
- Seller cancellation saves the listing removal before returning the reserved item. A failed save keeps the listing available.
- Numeric configuration values are checked and normalized to safe ranges. An invalid daily-reward timezone falls back to `Asia/Yangon`.
- Admin Panel > Reload Configuration refreshes active scoreboards and restarts the update task using the new configured interval.

These safeguards cover reported file-write failures during normal server operation. They are not a substitute for regular backups and do not constitute a crash-consistent distributed transaction across Minecraft player inventory saves and plugin YAML files.

## Features

### Player menu
- **Profile and wallet:** player identity, world, coordinates, health, level and coin balance.
- **Player statistics:** persistent playtime, mob kills, player kills and deaths.
- **Leaderboards:** top three players by wallet balance, mob kills and playtime.
- **Daily reward:** configurable coin reward, one claim per configured calendar day, configurable IANA timezone.
- **Multiple homes:** named homes, GUI teleport and deletion, pagination and permission-based limits.
- **Warps and spawn:** browse destinations, teleport, and use the configured server spawn.
- **Kits:** configurable kits, permissions, persistent cooldowns and inventory-capacity checks.
- **Shop:** buy configured items with coins directly through the GUI.
- **Player payments:** choose an online player in the GUI, then enter the amount in chat; transfers check sufficient funds, positive amounts and balance overflow.
- **Mob rewards:** configurable rewards for player-killed mob types.
- **Online players and TPA:** send requests and accept or deny incoming requests, with timeout, cooldown and inbox limits.
- **Quest Journal:** configurable block-gathering, building and playtime objectives with persistent progress and one-time coin claims.
- **Player Market:** persistent fixed-price listings, player purchases and seller cancellation; weapons, armor and combat equipment are excluded.
- **Sidebar scoreboard:** configurable title and refresh interval, with player-level toggle in Settings.
- **Rules, settings and server information.**

### Admin menu
- Set the server spawn, create warps and send announcements.
- Reload `config.yml`.
- **Economy Manager:** browse online players, deposit or withdraw 100 coins, or set a player's wallet balance through a chat prompt.
- **Create Storage Backup:** save the current SMPCore configuration and data files into a timestamped snapshot.

### Reliability and storage

- Configuration defaults and range validation live in `config/ConfigManager`; wallet reads, writes, transfers and rollback live in `economy/EconomyManager`.
- Storage is organized under `storage/`: `StorageManager` coordinates `BackupManager` and `AuditLogger`, while `AtomicFileWriter` handles atomic YAML file replacement.
- `QuestManager` owns quest configuration, progress, ready counts and reward claims; `TeleportManager` owns homes/warps persistence and shared teleport validation.
- GUI page construction/click routing, market workflows, TPA state and scoreboard state remain in `SMPCore.java`; the codebase is modularizing incrementally rather than claiming a complete service architecture.
- Player balances, statistics, daily reward claims, player names and kit cooldowns are stored in `players.yml`.
- Homes and warps use their own YAML files.
- Player Market listings and serialized item stacks are stored in `market.yml`; quest progress and scoreboard preferences are stored in `players.yml`.
- Existing 1.3.0 `homes.yml`, `warps.yml` and `players.yml` data is retained.
- Playtime is accumulated in-memory and periodically persisted; remaining session time is flushed on quit and plugin disable.
- Daily reward date is calculated using the configured timezone and is persisted together with the balance update.
- Shop purchases validate material, amount, permission, price and inventory capacity before charging.
- Player transfers update both wallet values in one YAML write and report success only after persistence succeeds.
- Uses Paper's `AsyncChatEvent` for GUI text prompts; Bukkit actions are scheduled onto the main thread.
- Inventory clicks and drags are cancelled while an SMPCore menu is open.
- Market listing/purchase/cancel actions run on the main server thread, verify item identity, enforce price/listing limits, check inventory capacity and reject invalid/unsupported materials.
- Quest progress is capped at each configured target; rewards are claimed once and only after completion.
- The sidebar uses the Paper 1.21.11 scoreboard API with Adventure Components for its objective title.
- No runtime plugin dependencies.

## Requirements

- Paper 1.21.11
- Java 21
- Maven 3.9+ to build from source

## Build

Run in the project directory:

```bash
mvn clean package
```

The plugin JAR will be created at:

```text
target/SMPCore-2.1.0.jar
```

For offline source checks that do not require Maven or the Paper API repository, run:

```bash
sh tools/validate.sh
```

This parses all production Java sources, validates Maven/YAML/XML metadata and module wiring, then compiles and runs the focused quest/teleport manager tests against isolated minimal API stubs. It does **not** replace `mvn clean package` against Paper API or a live server test.

## Install

1. Stop your Paper server and back up the entire `plugins/SMPCore` folder.
2. Build the project or use a compiled SMPCore JAR.
3. Copy `SMPCore-2.1.0.jar` into the server's `plugins` folder.
4. Start the server and run `/menu` in game.
5. The plugin creates `market.yml` automatically; existing `homes.yml`, `warps.yml` and `players.yml` remain in place.
6. Give staff `smpcore.admin` (operators receive it by default).

## Menu navigation

- **Main Menu:** Profile, Homes, Warps, Spawn, Kits, Shop, Pay a Player, Daily Reward, Player Statistics, Leaderboards, Quest Journal, Player Market, Rules, Online Players, TPA Requests, Settings, Server Information and Admin Panel.
- **Homes:** create a home via the chat prompt; click to teleport and right-click to delete. Type `cancel` to stop.
- **Kits:** click a kit to claim it; cooldown and inventory-capacity checks are applied.
- **Shop:** click an item to purchase it. If the inventory is full, the purchase is rejected before payment.
- **Pay a Player:** select an online player and enter a whole-number amount in chat. Type `cancel` to stop.
- **Online Players:** click a player head to send a TPA request.
- **TPA Requests:** left-click to accept; right-click to decline.
- **Daily Reward:** open the reward screen and click the central reward item. A second claim on the same configured calendar day is rejected.
- **Quest Journal:** click a completed objective to claim its coin reward. Progress is accumulated automatically for configured objective types.
- **Player Market:** open Player Market, click Sell Main-Hand Item, enter a fixed price in chat and confirm; browse listings to buy; use My Listings to cancel and reclaim your item. Type `cancel` to stop a price prompt. Only building, farming and utility items are eligible.
- **Settings:** toggle the sidebar scoreboard per player.
- **Admin Panel → Economy Manager:** choose an online player, then deposit 100, withdraw 100 or set their balance using a chat prompt.

## Configuration

Edit `plugins/SMPCore/config.yml`. New defaults are merged into the config on startup; existing values are preserved.

### Statistics and daily rewards

```yaml
stats:
  enabled: true

daily-rewards:
  enabled: true
  amount: 100
  timezone: Asia/Yangon
```

- `stats.enabled` controls playtime, mob-kill, player-kill and death tracking.
- `daily-rewards.amount` is the whole-coin reward.
- `daily-rewards.timezone` controls the calendar-day reset. Use a valid IANA timezone such as `Asia/Yangon` or `UTC`.
- A claim is recorded in `players.yml` with the wallet update. Players can claim once per calendar date in the configured timezone.

### Economy

```yaml
economy:
  enabled: true
  starting-balance: 100
  currency-symbol: "$"
  max-payment: 1000000
  reward-message: true
  mob-rewards:
    ZOMBIE: 2
    SKELETON: 2
    SPIDER: 1
    CREEPER: 3
```

- `starting-balance` is assigned once to players without a saved balance.
- `currency-symbol` is a display prefix; amounts are whole-number coins.
- `max-payment` limits player-to-player transfers.
- `mob-rewards` maps Bukkit entity type names to coin rewards. Only player-killed mobs grant rewards. Set values to `0` to disable individual rewards.

### Shop

```yaml
shop:
  enabled: true
  bread:
    material: BREAD
    amount: 16
    price: 20
    display-name: "&fBread x16"
    permission: ""
```

Add products as sections directly under `shop`. `material` must be a valid item material; `amount` must be 1–2,304; `price` must be 0 or greater. `permission` can be empty for unrestricted purchase. Product items are split into legal stack sizes automatically.

### Homes and kits

```yaml
homes:
  default-limit: 3
  permission-limits:
    - permission: smpcore.homes.5
      limit: 5

kits:
  enabled: true
  starter:
    display-name: "&aStarter Kit"
    icon: CHEST
    cooldown-seconds: 86400
    permission: smpcore.kit.starter
    items:
      - BREAD:16
      - TORCH:16
      - STONE_SWORD:1
```

Kit cooldowns are limited to 0–31,536,000 seconds (one year) to avoid millisecond timestamp overflow.

### Other settings

```yaml
menu:
  sounds: true
broadcasts:
  join-leave: true
tpa:
  enabled: true
  timeout-seconds: 60
  cooldown-seconds: 10
  max-pending-per-player: 10
```


### Automatic backups and audit log

```yaml
storage:
  auto-backup:
    enabled: true
    interval-minutes: 360
    retention-count: 10
```

- `interval-minutes` accepts 15–10,080 minutes.
- `retention-count` accepts 1–50 snapshots.
- Kit cooldowns are normalized to 0–31,536,000 seconds to prevent millisecond overflow.
- Backups are stored under `plugins/SMPCore/backups/` in timestamped folders.
- Manual backup is available from `/menu` → Admin Panel → Create Storage Backup.
- Audit records are stored in `plugins/SMPCore/logs/audit.log`; one previous log segment is retained as `audit.log.1`.
- Backups include SMPCore configuration, YAML data and available audit log segments. They do not include world files, server properties or other plugins.

### Quests, player market and scoreboard

```yaml
quests:
  enabled: true
  resource-gatherer:
    enabled: true
    display-name: "&aResource Gatherer"
    description: "Break 64 blocks."
    type: BLOCKS_BROKEN
    target: 64
    reward: 200
    icon: IRON_PICKAXE
  builder:
    enabled: true
    display-name: "&bBuilder"
    description: "Place 32 blocks."
    type: BLOCKS_PLACED
    target: 32
    reward: 200
    icon: BRICKS
  playtime:
    enabled: true
    display-name: "&eDedicated Player"
    description: "Play for 60 minutes."
    type: PLAYTIME_SECONDS
    target: 3600
    reward: 300
    icon: CLOCK
market:
  enabled: true
  max-listings-per-player: 5
  max-price: 1000000000
scoreboard:
  enabled: true
  title: "&b&lSMPCore"
  update-ticks: 40
```

- Supported quest types are `BLOCKS_BROKEN`, `BLOCKS_PLACED` and `PLAYTIME_SECONDS`. Configure targets and coin rewards per quest. Progress is stored in `players.yml`; completed rewards can be claimed once.
- The player market is a **fixed-price marketplace**, not an auction or bidding system. Listings persist in `market.yml`. Set a per-player listing cap and a maximum price. Combat-oriented items are excluded; the market is intended for building, farming and utility resources.
- The sidebar can be disabled globally with `scoreboard.enabled: false`; each player can also toggle their own display in `/menu` → Settings. `update-ticks` is normalized to the range 20–1200 ticks. The plugin does not repeatedly reclaim a scoreboard after another plugin takes ownership; in that case the SMPCore sidebar pauses instead of fighting the other plugin.

## Permissions

- `smpcore.use` — access to `/menu`; true by default.
- `smpcore.admin` — Admin Panel and Economy Manager; operator-only by default.
- `smpcore.homes.5` — increases home limit to five when configured; false by default.
- `smpcore.kit.starter` — claim the default starter kit; true by default.
- Product-specific permissions can be set in each `shop.<product>.permission` section.

## Upgrade from 2.0.0 or 1.9.0

1. Stop the server and back up the complete `plugins/SMPCore` folder.
2. Replace the old JAR with `SMPCore-2.1.0.jar`.
3. Start the server. The existing `players.yml`, `homes.yml`, `warps.yml` and `market.yml` paths are unchanged; no data migration is intended.
4. Confirm the console reports `SMPCore 2.1.0 enabled`, then test `/menu`, home/warp creation and deletion, quest progress/claims, profile/statistics pages and inventory clicks on a staging server.

The `plugin.yml` API metadata remains `1.21` (Paper's major/minor API version), while the Maven dependency and server target remain `1.21.11`.

## Upgrade from 1.5.0 or earlier

1. Stop the server and back up the complete `plugins/SMPCore` folder.
2. Replace the old JAR with `SMPCore-2.1.0.jar`.
3. Start the server. Existing `market.yml`, `homes.yml`, `warps.yml` and `players.yml` files are retained.
4. Review `market`, `homes`, `tpa`, `daily-rewards` and `scoreboard` values in `config.yml`; invalid numeric values are normalized to defaults and logged.
5. On a staging server, test one listing, purchase, cancellation and config reload before upgrading a live SMP.

## Upgrade from 1.4.0

1. Stop the server and back up the complete `plugins/SMPCore` folder.
2. Replace the old JAR with `SMPCore-2.1.0.jar`.
3. Start the server. `market.yml` is created automatically; homes, warps, balances, statistics, daily claims and kit cooldowns remain in their existing files.
4. Review the new `quests`, `market` and `scoreboard` sections in `config.yml`.
5. Test one listing, one purchase, one cancellation and one quest claim on a staging server before upgrading a live SMP.

## Upgrade from 1.3.0

1. Stop the server and back up the entire `plugins/SMPCore` folder.
2. Replace the old JAR with `SMPCore-2.1.0.jar`.
3. Start the server. Existing homes, warps, wallet balances, kit cooldowns and personal settings are retained.
4. New `stats` and `daily-rewards` defaults are added to `config.yml`. Review the reward amount and timezone before enabling daily rewards.
5. Player statistics begin accumulating after the upgrade; historical playtime/kills/deaths are not reconstructed.

Do not delete `homes.yml`, `warps.yml` or `players.yml` during an upgrade.

## Compatibility note

This build intentionally remains targeted at Paper 1.21.11 / Java 21. Paper's current requirements table lists Java 21 for Minecraft 1.20–1.21.11 and Java 25 for 26.1+. Supporting Paper 26.x should be handled as a separate compatibility target with its own build and live-server testing; this source does not claim 26.x compatibility.


## 1.8.0 architecture update

- Extracted configuration defaults and validation into `config/ConfigManager.java`.
- Extracted wallet reads, writes, overflow protection, atomic two-wallet transfers and rollback into `economy/EconomyManager.java`.
- Added `storage/StorageManager.java` as the backup/audit facade.
- Added `storage/AtomicFileWriter.java` with unique temporary files, file-channel flush and atomic replace fallback; YAML storage writes use this helper.
- Preserved the existing `/menu` entry point and YAML data layout.
- Kept the target at Paper 1.21.11 / Java 21.

Build with JDK 21 and Maven 3.9+: `mvn clean package`. Full Paper API compilation and in-server integration tests must be run in an environment with repository access and a Paper 1.21.11 test server.

## 2.1.0 modularization update

- `commands/MenuCommand.java` is the Bukkit command adapter for `/menu` and delegates to the plugin's existing permission and menu workflow.
- `events/InventoryMenuListener.java` handles menu click and drag entry points.
- `events/ChatInputListener.java` owns the Paper `AsyncChatEvent` registration for text-based menu prompts.
- `events/QuestGameplayListener.java` routes block progression and mob reward events.
- `events/PlayerLifecycleListener.java` routes player death, join and quit events.
- `EventManager` registers these listener instances by identity and tears them all down on disable.
- `SMPCore` no longer implements Bukkit's `Listener` or `CommandExecutor`; it remains the JavaPlugin lifecycle entry point and exposes the workflow methods used by the adapters. This is a deliberate boundary extraction, not a claim that all GUI/domain workflows have been moved into services.
- `PlayerManager` now validates relative YAML paths, rejects malformed stat keys, protects counters against overflow, and returns immutable stored-player ID snapshots.

### Paper metadata correction

The compile target remains `paper-api:1.21.11-R0.1-SNAPSHOT` with Java 21. The `plugin.yml` `api-version` is now `1.21`. Paper's `PluginMeta` Javadocs describe this value as a major/minor version and state that patch versions such as `1.18.2` are unified to their major release version. Therefore the game/server target (1.21.11) and plugin API metadata (1.21) are intentionally different.

### Validation boundary

Java 21 standalone smoke tests were run for the newly extracted manager classes against minimal API stubs. YAML/XML and ZIP checks also passed. Full Maven compilation against the Paper API and live Paper server integration tests were not run in this environment.
