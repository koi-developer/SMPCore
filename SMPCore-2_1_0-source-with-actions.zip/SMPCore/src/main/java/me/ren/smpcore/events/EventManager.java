package me.ren.smpcore.events;

import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/** Owns listener registration for the plugin and provides an explicit teardown point. */
public final class EventManager {
    private final Plugin plugin;
    private final Set<Listener> listeners = Collections.newSetFromMap(new IdentityHashMap<>());

    public EventManager(Plugin plugin) {
        if (plugin == null) throw new IllegalArgumentException("Plugin must not be null.");
        this.plugin = plugin;
    }

    public synchronized void register(Listener listener) {
        if (listener == null) throw new IllegalArgumentException("Listener must not be null.");
        if (listeners.contains(listener)) return;
        plugin.getServer().getPluginManager().registerEvents(listener, plugin);
        listeners.add(listener);
    }

    public synchronized int registeredListenerCount() {
        return listeners.size();
    }

    public synchronized void unregisterAll() {
        for (Listener listener : listeners) HandlerList.unregisterAll(listener);
        listeners.clear();
    }
}
