package me.ren.smpcore.teleport;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Owns home/warp persistence and the common synchronous teleport guard.
 * All methods that read or modify Bukkit worlds or YAML must run on the server thread.
 */
public final class TeleportManager {
    private static final Pattern SAFE_NAME = Pattern.compile("[A-Za-z0-9_-]{1,16}");

    private final YamlConfiguration homes;
    private final YamlConfiguration warps;
    private final BooleanSupplier saveHomes;
    private final BooleanSupplier saveWarps;
    private final Consumer<String> logger;

    public TeleportManager(YamlConfiguration homes, YamlConfiguration warps,
                           BooleanSupplier saveHomes, BooleanSupplier saveWarps,
                           Consumer<String> logger) {
        if (homes == null || warps == null || saveHomes == null || saveWarps == null) {
            throw new IllegalArgumentException("Teleport manager dependencies must not be null.");
        }
        this.homes = homes;
        this.warps = warps;
        this.saveHomes = saveHomes;
        this.saveWarps = saveWarps;
        this.logger = logger == null ? ignored -> { } : logger;
    }

    public List<String> getHomeNames(UUID playerId) {
        if (playerId == null) return List.of();
        String path = "homes." + playerId;
        ConfigurationSection section = homes.getConfigurationSection(path);
        if (section == null) return List.of();
        List<String> names = new ArrayList<>();
        for (String name : section.getKeys(false)) {
            if (isSafeName(name) && homes.contains(path + "." + name + ".world")) names.add(name);
        }
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return List.copyOf(names);
    }

    public Location getHome(UUID playerId, String name) {
        if (playerId == null || !isSafeName(name)) return null;
        return readLocation(homes, "homes." + playerId + "." + normalize(name));
    }

    public List<String> getWarpNames() {
        ConfigurationSection section = warps.getConfigurationSection("warps");
        if (section == null) return List.of();
        List<String> names = new ArrayList<>();
        for (String name : section.getKeys(false)) if (isSafeName(name)) names.add(name);
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return List.copyOf(names);
    }

    public Location getWarp(String name) {
        if (!isSafeName(name)) return null;
        return readLocation(warps, "warps." + normalize(name));
    }

    public boolean createHome(UUID playerId, String name, Location location) {
        if (playerId == null || !isSafeName(name) || !isUsable(location)) return false;
        String path = "homes." + playerId + "." + normalize(name);
        if (homes.contains(path + ".world")) return false;
        return writeLocationTransaction(homes, path, location, saveHomes, "home creation");
    }

    public boolean deleteHome(UUID playerId, String name) {
        if (playerId == null || !isSafeName(name)) return false;
        String path = "homes." + playerId + "." + normalize(name);
        if (!homes.contains(path + ".world")) return false;
        return deleteLocationTransaction(homes, path, saveHomes, "home deletion");
    }

    public boolean createWarp(String name, Location location) {
        if (!isSafeName(name) || !isUsable(location)) return false;
        String path = "warps." + normalize(name);
        if (warps.contains(path)) return false;
        return writeLocationTransaction(warps, path, location, saveWarps, "warp creation");
    }

    public boolean deleteWarp(String name) {
        if (!isSafeName(name)) return false;
        String path = "warps." + normalize(name);
        if (!warps.contains(path)) return false;
        return deleteLocationTransaction(warps, path, saveWarps, "warp deletion");
    }

    public TeleportResult teleport(Player player, Location destination) {
        if (player == null || !isUsable(destination)) return TeleportResult.UNAVAILABLE;
        if (!destination.getWorld().getWorldBorder().isInside(destination)) return TeleportResult.OUTSIDE_BORDER;
        try {
            return player.teleport(destination.clone()) ? TeleportResult.SUCCESS : TeleportResult.CANCELLED;
        } catch (RuntimeException exception) {
            logger.accept("Teleport failed: " + exception.getMessage());
            return TeleportResult.ERROR;
        }
    }

    public static boolean isSafeName(String name) {
        return name != null && SAFE_NAME.matcher(name).matches();
    }

    private boolean writeLocationTransaction(YamlConfiguration yaml, String path, Location location,
                                              BooleanSupplier save, String operation) {
        String snapshot = yaml.saveToString();
        writeLocation(yaml, path, location);
        if (save.getAsBoolean()) return true;
        restore(yaml, snapshot, save, operation);
        return false;
    }

    private boolean deleteLocationTransaction(YamlConfiguration yaml, String path,
                                              BooleanSupplier save, String operation) {
        String snapshot = yaml.saveToString();
        yaml.set(path, null);
        if (save.getAsBoolean()) return true;
        restore(yaml, snapshot, save, operation);
        return false;
    }

    private void restore(YamlConfiguration yaml, String snapshot, BooleanSupplier save, String operation) {
        try {
            yaml.loadFromString(snapshot);
            if (!save.getAsBoolean()) {
                logger.accept("Could not persist rollback for " + operation + ". Restore from the latest SMPCore backup if needed.");
            }
        } catch (InvalidConfigurationException exception) {
            logger.accept("Could not restore YAML after " + operation + ": " + exception.getMessage());
        }
    }

    private static Location readLocation(YamlConfiguration yaml, String path) {
        if (!yaml.contains(path + ".world")) return null;
        String worldName = yaml.getString(path + ".world");
        World world = worldName == null ? null : Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = yaml.getDouble(path + ".x", Double.NaN);
        double y = yaml.getDouble(path + ".y", Double.NaN);
        double z = yaml.getDouble(path + ".z", Double.NaN);
        double yaw = yaml.getDouble(path + ".yaw", 0.0D);
        double pitch = yaml.getDouble(path + ".pitch", 0.0D);
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)
                || !Double.isFinite(yaw) || !Double.isFinite(pitch)
                || Math.abs(yaw) > Float.MAX_VALUE || Math.abs(pitch) > Float.MAX_VALUE) return null;
        return new Location(world, x, y, z, (float) yaw, (float) pitch);
    }

    private static void writeLocation(YamlConfiguration yaml, String path, Location location) {
        Location safe = location.clone();
        yaml.set(path + ".world", safe.getWorld().getName());
        yaml.set(path + ".x", safe.getX());
        yaml.set(path + ".y", safe.getY());
        yaml.set(path + ".z", safe.getZ());
        yaml.set(path + ".yaw", safe.getYaw());
        yaml.set(path + ".pitch", safe.getPitch());
    }

    private static boolean isUsable(Location location) {
        return location != null && location.getWorld() != null
                && Double.isFinite(location.getX()) && Double.isFinite(location.getY())
                && Double.isFinite(location.getZ()) && Float.isFinite(location.getYaw())
                && Float.isFinite(location.getPitch());
    }

    private static String normalize(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    public enum TeleportResult {
        SUCCESS, UNAVAILABLE, OUTSIDE_BORDER, CANCELLED, ERROR
    }
}
