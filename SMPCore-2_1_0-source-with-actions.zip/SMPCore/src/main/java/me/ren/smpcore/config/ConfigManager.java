package me.ren.smpcore.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.DateTimeException;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;

/** Owns SMPCore defaults and validation so gameplay classes only consume normalized settings. */
public final class ConfigManager {
    private final JavaPlugin plugin;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void applyDefaultsAndValidate() {
        plugin.getConfig().addDefault("menu.sounds", true);
        plugin.getConfig().addDefault("broadcasts.join-leave", true);
        plugin.getConfig().addDefault("tpa.enabled", true);
        plugin.getConfig().addDefault("tpa.timeout-seconds", 60);
        plugin.getConfig().addDefault("tpa.cooldown-seconds", 10);
        plugin.getConfig().addDefault("tpa.max-pending-per-player", 10);
        plugin.getConfig().addDefault("homes.default-limit", 3);
        plugin.getConfig().addDefault("homes.permission-limits", List.of(Map.of("permission", "smpcore.homes.5", "limit", 5)));
        plugin.getConfig().addDefault("kits.enabled", true);
        plugin.getConfig().addDefault("kits.starter.display-name", "&aStarter Kit");
        plugin.getConfig().addDefault("kits.starter.icon", "CHEST");
        plugin.getConfig().addDefault("kits.starter.cooldown-seconds", 86400);
        plugin.getConfig().addDefault("kits.starter.permission", "smpcore.kit.starter");
        plugin.getConfig().addDefault("kits.starter.items", List.of("BREAD:16", "TORCH:16", "STONE_SWORD:1"));
        plugin.getConfig().addDefault("economy.enabled", true);
        plugin.getConfig().addDefault("economy.starting-balance", 100L);
        plugin.getConfig().addDefault("economy.currency-symbol", "$");
        plugin.getConfig().addDefault("economy.max-payment", 1000000L);
        plugin.getConfig().addDefault("economy.reward-message", true);
        plugin.getConfig().addDefault("stats.enabled", true);
        plugin.getConfig().addDefault("daily-rewards.enabled", true);
        plugin.getConfig().addDefault("daily-rewards.amount", 100L);
        plugin.getConfig().addDefault("daily-rewards.timezone", "Asia/Yangon");
        plugin.getConfig().addDefault("economy.mob-rewards.ZOMBIE", 2L);
        plugin.getConfig().addDefault("economy.mob-rewards.SKELETON", 2L);
        plugin.getConfig().addDefault("economy.mob-rewards.SPIDER", 1L);
        plugin.getConfig().addDefault("economy.mob-rewards.CREEPER", 3L);
        plugin.getConfig().addDefault("shop.enabled", true);
        plugin.getConfig().addDefault("shop.bread.material", "BREAD");
        plugin.getConfig().addDefault("shop.bread.amount", 16);
        plugin.getConfig().addDefault("shop.bread.price", 20L);
        plugin.getConfig().addDefault("shop.bread.display-name", "&fBread x16");
        plugin.getConfig().addDefault("shop.bread.permission", "");
        plugin.getConfig().addDefault("shop.torch.material", "TORCH");
        plugin.getConfig().addDefault("shop.torch.amount", 16);
        plugin.getConfig().addDefault("shop.torch.price", 15L);
        plugin.getConfig().addDefault("shop.torch.display-name", "&eTorch x16");
        plugin.getConfig().addDefault("shop.torch.permission", "");
        plugin.getConfig().addDefault("shop.iron-ingot.material", "IRON_INGOT");
        plugin.getConfig().addDefault("shop.iron-ingot.amount", 8);
        plugin.getConfig().addDefault("shop.iron-ingot.price", 80L);
        plugin.getConfig().addDefault("shop.iron-ingot.display-name", "&fIron Ingots x8");
        plugin.getConfig().addDefault("shop.iron-ingot.permission", "");
        plugin.getConfig().addDefault("quests.enabled", true);
        plugin.getConfig().addDefault("quests.resource-gatherer.enabled", true);
        plugin.getConfig().addDefault("quests.resource-gatherer.display-name", "&aResource Gatherer");
        plugin.getConfig().addDefault("quests.resource-gatherer.description", "Break 64 blocks.");
        plugin.getConfig().addDefault("quests.resource-gatherer.type", "BLOCKS_BROKEN");
        plugin.getConfig().addDefault("quests.resource-gatherer.target", 64L);
        plugin.getConfig().addDefault("quests.resource-gatherer.reward", 200L);
        plugin.getConfig().addDefault("quests.resource-gatherer.icon", "IRON_PICKAXE");
        plugin.getConfig().addDefault("quests.builder.enabled", true);
        plugin.getConfig().addDefault("quests.builder.display-name", "&bBuilder");
        plugin.getConfig().addDefault("quests.builder.description", "Place 32 blocks.");
        plugin.getConfig().addDefault("quests.builder.type", "BLOCKS_PLACED");
        plugin.getConfig().addDefault("quests.builder.target", 32L);
        plugin.getConfig().addDefault("quests.builder.reward", 200L);
        plugin.getConfig().addDefault("quests.builder.icon", "BRICKS");
        plugin.getConfig().addDefault("quests.playtime.enabled", true);
        plugin.getConfig().addDefault("quests.playtime.display-name", "&eDedicated Player");
        plugin.getConfig().addDefault("quests.playtime.description", "Play for 60 minutes.");
        plugin.getConfig().addDefault("quests.playtime.type", "PLAYTIME_SECONDS");
        plugin.getConfig().addDefault("quests.playtime.target", 3600L);
        plugin.getConfig().addDefault("quests.playtime.reward", 300L);
        plugin.getConfig().addDefault("quests.playtime.icon", "CLOCK");
        plugin.getConfig().addDefault("market.enabled", true);
        plugin.getConfig().addDefault("market.max-listings-per-player", 5);
        plugin.getConfig().addDefault("market.max-price", 1000000000L);
        plugin.getConfig().addDefault("scoreboard.enabled", true);
        plugin.getConfig().addDefault("scoreboard.title", "&b&lSMPCore");
        plugin.getConfig().addDefault("scoreboard.update-ticks", 40L);
        plugin.getConfig().addDefault("storage.auto-backup.enabled", true);
        plugin.getConfig().addDefault("storage.auto-backup.interval-minutes", 360);
        plugin.getConfig().addDefault("storage.auto-backup.retention-count", 10);
        plugin.getConfig().options().copyDefaults(true);
        validateConfigValues();
        plugin.saveConfig();
    }

    /** Normalize unsafe or out-of-range settings before any gameplay code consumes them. */
    private void validateConfigValues() {
        normalizeLong("economy.starting-balance", 0L, Long.MAX_VALUE, 100L);
        normalizeLong("economy.max-payment", 1L, Long.MAX_VALUE, 1000000L);
        normalizeLong("daily-rewards.amount", 0L, Long.MAX_VALUE, 100L);
        normalizeLong("market.max-price", 1L, Long.MAX_VALUE, 1000000000L);
        normalizeInt("market.max-listings-per-player", 1, 50, 5);
        normalizeInt("homes.default-limit", 1, 100, 3);
        normalizeInt("tpa.timeout-seconds", 5, 3600, 60);
        normalizeInt("tpa.cooldown-seconds", 0, 3600, 10);
        normalizeInt("tpa.max-pending-per-player", 1, 50, 10);
        normalizeLong("scoreboard.update-ticks", 20L, 1200L, 40L);
        normalizeInt("storage.auto-backup.interval-minutes", 15, 10080, 360);
        normalizeInt("storage.auto-backup.retention-count", 1, 50, 10);
        ConfigurationSection kitRoot = plugin.getConfig().getConfigurationSection("kits");
        if (kitRoot != null) {
            for (String kitKey : kitRoot.getKeys(false)) {
                if (kitRoot.isConfigurationSection(kitKey)) {
                    normalizeLong("kits." + kitKey + ".cooldown-seconds", 0L, 31536000L, 86400L);
                }
            }
        }

        String timezone = plugin.getConfig().getString("daily-rewards.timezone", "Asia/Yangon");
        try {
            ZoneId.of(timezone == null ? "Asia/Yangon" : timezone);
        } catch (DateTimeException exception) {
            plugin.getLogger().warning("Invalid daily-rewards.timezone; using Asia/Yangon.");
            plugin.getConfig().set("daily-rewards.timezone", "Asia/Yangon");
        }
    }

    private void normalizeLong(String path, long minimum, long maximum, long fallback) {
        long value = plugin.getConfig().getLong(path, fallback);
        if (value < minimum || value > maximum) {
            plugin.getLogger().warning("Invalid " + path + " value; resetting to " + fallback + ".");
            plugin.getConfig().set(path, fallback);
        }
    }

    private void normalizeInt(String path, int minimum, int maximum, int fallback) {
        int value = plugin.getConfig().getInt(path, fallback);
        if (value < minimum || value > maximum) {
            plugin.getLogger().warning("Invalid " + path + " value; resetting to " + fallback + ".");
            plugin.getConfig().set(path, fallback);
        }
    }


}
