package me.ren.smpcore.menu;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Supplier;

/** Creates SMPCore's inventory menus and owns the holder/session metadata. */
public final class MenuManager {
    public static final int MENU_SIZE = 54;

    /** A per-viewer menu session. The page type is supplied by the owning plugin. */
    public static final class MenuHolder<P> implements InventoryHolder {
        public final P page;
        public final UUID viewer;
        public final int pageIndex;
        private Inventory inventory;
        private List<String> entries = List.of();

        public MenuHolder(P page, UUID viewer, int pageIndex) {
            this.page = page;
            this.viewer = viewer;
            this.pageIndex = Math.max(0, pageIndex);
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void attach(Inventory inventory) {
            this.inventory = inventory;
        }

        public void setEntries(List<String> entries) {
            this.entries = entries == null ? List.of() : List.copyOf(entries);
        }

        public List<String> entries() {
            return entries;
        }
    }

    /** Creates a framed 6-row inventory with immutable session metadata. */
    public <P> Inventory createMenu(Player player, P page, int pageIndex, String title,
                                    Function<String, String> titleFormatter,
                                    Supplier<ItemStack> frameItemFactory) {
        if (player == null || page == null || titleFormatter == null || frameItemFactory == null) {
            throw new IllegalArgumentException("Menu arguments must not be null.");
        }

        MenuHolder<P> holder = new MenuHolder<>(page, player.getUniqueId(), pageIndex);
        Inventory inventory = Bukkit.createInventory(holder, MENU_SIZE, titleFormatter.apply(title));
        holder.attach(inventory);
        fillFrame(inventory, frameItemFactory.get());
        return inventory;
    }

    private void fillFrame(Inventory inventory, ItemStack pane) {
        if (pane == null || pane.getType().isAir()) {
            throw new IllegalArgumentException("Frame item must be a non-air ItemStack.");
        }
        for (int slot = 0; slot < 9; slot++) setClone(inventory, slot, pane);
        for (int slot = 45; slot < 54; slot++) setClone(inventory, slot, pane);
        for (int slot : new int[]{9, 17, 18, 26, 27, 35, 36, 44}) setClone(inventory, slot, pane);
    }

    private void setClone(Inventory inventory, int slot, ItemStack pane) {
        inventory.setItem(slot, pane.clone());
    }
}
