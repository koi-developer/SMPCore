package me.ren.smpcore.storage;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Stream;

/** Creates consistent point-in-time copies of the plugin's YAML files. */
public final class BackupManager {
    private static final DateTimeFormatter DIRECTORY_FORMAT =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS").withZone(ZoneOffset.UTC);

    private final Path backupRoot;
    private final Consumer<String> logger;

    public BackupManager(Path backupRoot, Consumer<String> logger) {
        this.backupRoot = backupRoot;
        this.logger = logger == null ? ignored -> { } : logger;
    }

    public BackupResult createSnapshot(Map<String, Path> sources, int retention) {
        if (sources == null || sources.isEmpty()) {
            return BackupResult.failure("No storage files were supplied.");
        }

        Path staging = null;
        try {
            Files.createDirectories(backupRoot);
            String baseName = DIRECTORY_FORMAT.format(Instant.now());
            Path destination = backupRoot.resolve(baseName);
            if (Files.exists(destination)) {
                destination = backupRoot.resolve(baseName + "-" + UUID.randomUUID().toString().substring(0, 8));
            }
            staging = backupRoot.resolve(".tmp-" + UUID.randomUUID());
            Files.createDirectory(staging);

            List<String> manifestLines = new ArrayList<>();
            manifestLines.add("created-at=" + Instant.now());
            int copied = 0;
            for (Map.Entry<String, Path> entry : sources.entrySet()) {
                String fileName = entry.getKey();
                Path source = entry.getValue();
                if (fileName == null || fileName.isBlank() || fileName.contains("/") || fileName.contains("\\")
                        || source == null || !Files.isRegularFile(source)) {
                    continue;
                }
                Path target = staging.resolve(fileName).normalize();
                if (!target.getParent().equals(staging)) {
                    throw new IOException("Invalid backup file name: " + fileName);
                }
                Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                manifestLines.add("file=" + fileName + ";bytes=" + Files.size(target));
                copied++;
            }
            if (copied == 0) {
                deleteTree(staging);
                return BackupResult.failure("No source storage files were available to back up.");
            }
            Files.write(staging.resolve("MANIFEST.txt"), manifestLines);
            moveDirectory(staging, destination);
            staging = null;

            pruneOldBackups(Math.max(1, retention));
            logger.accept("Created backup snapshot " + destination.getFileName() + " (" + copied + " files).");
            return BackupResult.success(destination, copied);
        } catch (Exception exception) {
            if (staging != null) {
                try {
                    deleteTree(staging);
                } catch (IOException cleanupException) {
                    logger.accept("Could not clean temporary backup directory: " + cleanupException.getMessage());
                }
            }
            logger.accept("Backup failed: " + exception.getMessage());
            return BackupResult.failure(exception.getMessage());
        }
    }

    private void pruneOldBackups(int retention) throws IOException {
        if (!Files.isDirectory(backupRoot)) return;
        List<Path> snapshots = new ArrayList<>();
        List<Path> abandonedTemporaryDirectories = new ArrayList<>();
        try (Stream<Path> children = Files.list(backupRoot)) {
            children.filter(Files::isDirectory).forEach(path -> {
                if (path.getFileName().toString().startsWith(".tmp-")) {
                    abandonedTemporaryDirectories.add(path);
                } else {
                    snapshots.add(path);
                }
            });
        }
        for (Path abandoned : abandonedTemporaryDirectories) deleteTree(abandoned);
        snapshots.sort(Comparator.comparing(path -> path.getFileName().toString(), Comparator.reverseOrder()));
        for (int i = retention; i < snapshots.size(); i++) {
            deleteTree(snapshots.get(i));
        }
    }

    private static void moveDirectory(Path source, Path target) throws IOException {
        try {
            Files.move(source, target, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException exception) {
            Files.move(source, target);
        }
    }

    private static void deleteTree(Path root) throws IOException {
        if (root == null || !Files.exists(root)) return;
        try (Stream<Path> paths = Files.walk(root)) {
            for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) {
                Files.deleteIfExists(path);
            }
        }
    }

    public record BackupResult(boolean success, Path directory, int filesCopied, String message) {
        private static BackupResult success(Path directory, int filesCopied) {
            return new BackupResult(true, directory, filesCopied, "Backup created.");
        }

        private static BackupResult failure(String message) {
            return new BackupResult(false, null, 0, message == null ? "Unknown backup error." : message);
        }
    }
}
