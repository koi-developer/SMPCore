package me.ren.smpcore.commands;

import me.ren.smpcore.SMPCore;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.Objects;

/** Adapts Bukkit's command API to the plugin's menu workflow. */
public final class MenuCommand implements CommandExecutor {
    private final SMPCore plugin;

    public MenuCommand(SMPCore plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return plugin.onCommand(sender, command, label, args);
    }
}
