package me.ren.smpcore.storage;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.UUID;
import java.util.function.Consumer;

/** Small bounded audit log for economy, market and administrative operations. */
public final class AuditLogger {
    private static final long MAX_LOG_BYTES = 2L * 1024L * 1024L;

    private final Path logFile;
    private final Consumer<String> logger;

    public AuditLogger(Path logFile, Consumer<String> logger) {
        this.logFile = logFile;
        this.logger = logger == null ? ignored -> { } : logger;
    }

    public synchronized void record(String action, UUID actor, UUID target, String details) {
        try {
            Files.createDirectories(logFile.getParent());
            rotateIfNeeded();
            String line = Instant.now()
                    + " action=" + safe(action)
                    + " actor=" + (actor == null ? "SYSTEM" : actor)
                    + " target=" + (target == null ? "-" : target)
                    + " details=" + safe(details);
            Files.writeString(logFile, line + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        } catch (Exception exception) {
            logger.accept("Could not write audit log: " + exception.getMessage());
        }
    }

    private void rotateIfNeeded() throws IOException {
        if (!Files.exists(logFile) || Files.size(logFile) < MAX_LOG_BYTES) return;
        Path previous = logFile.resolveSibling(logFile.getFileName() + ".1");
        Files.move(logFile, previous, StandardCopyOption.REPLACE_EXISTING);
    }

    private static String safe(String value) {
        if (value == null || value.isBlank()) return "-";
        String sanitized = value.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
                .replace('=', ':').trim();
        return sanitized.length() > 240 ? sanitized.substring(0, 240) : sanitized;
    }
}
