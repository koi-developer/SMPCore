package me.ren.smpcore.events;

import me.ren.smpcore.SMPCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Objects;

/** Handles player statistics and join/quit lifecycle events. */
public final class PlayerLifecycleListener implements Listener {
    private final SMPCore plugin;

    public PlayerLifecycleListener(SMPCore plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        plugin.onPlayerDeath(event);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        plugin.onJoin(event);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.onQuit(event);
    }
}
