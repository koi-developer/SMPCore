package me.ren.smpcore.economy;

import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.UUID;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

/**
 * Owns wallet persistence and rollback. All methods must be called on the server thread;
 * Bukkit YAML configuration is not a concurrent wallet database.
 */
public final class EconomyManager {
    private final YamlConfiguration playerData;
    private final LongSupplier startingBalance;
    private final BooleanSupplier save;
    private final Runnable markDirty;
    private final Consumer<String> logger;

    public EconomyManager(YamlConfiguration playerData, LongSupplier startingBalance,
                          BooleanSupplier save, Runnable markDirty, Consumer<String> logger) {
        this.playerData = playerData;
        this.startingBalance = startingBalance;
        this.save = save;
        this.markDirty = markDirty;
        this.logger = logger == null ? ignored -> { } : logger;
    }

    public long getBalance(UUID playerId) {
        String path = balancePath(playerId);
        if (playerData.contains(path)) return Math.max(0L, playerData.getLong(path, 0L));

        String snapshot = playerData.saveToString();
        long initial = Math.max(0L, startingBalance.getAsLong());
        playerData.set(path, initial);
        if (!save.getAsBoolean()) restore(snapshot, "initial wallet creation");
        return initial;
    }

    public boolean setBalance(UUID playerId, long amount) {
        if (playerId == null || amount < 0L) return false;
        String snapshot = playerData.saveToString();
        playerData.set(balancePath(playerId), amount);
        if (save.getAsBoolean()) return true;
        restore(snapshot, "wallet update");
        return false;
    }

    public boolean addBalance(UUID playerId, long amount) {
        if (playerId == null || amount <= 0L) return false;
        long current = getBalance(playerId);
        if (current > Long.MAX_VALUE - amount) return false;
        return setBalance(playerId, current + amount);
    }

    /** Applies two wallet changes and commits them with one persistent write. */
    public boolean transfer(UUID senderId, UUID recipientId, long amount) {
        if (senderId == null || recipientId == null || senderId.equals(recipientId) || amount <= 0L) return false;
        long senderBalance = getBalance(senderId);
        long recipientBalance = getBalance(recipientId);
        if (senderBalance < amount || recipientBalance > Long.MAX_VALUE - amount) return false;

        String snapshot = playerData.saveToString();
        playerData.set(balancePath(senderId), senderBalance - amount);
        playerData.set(balancePath(recipientId), recipientBalance + amount);
        if (save.getAsBoolean()) return true;
        restore(snapshot, "coin transfer");
        return false;
    }

    public boolean updatePlayerSettings(Consumer<YamlConfiguration> mutation, String operation) {
        if (mutation == null) return false;
        String snapshot = playerData.saveToString();
        try {
            mutation.accept(playerData);
        } catch (RuntimeException exception) {
            restore(snapshot, operation);
            logger.accept("Could not apply " + operation + ": " + exception.getMessage());
            return false;
        }
        if (save.getAsBoolean()) return true;
        restore(snapshot, operation);
        return false;
    }

    /** Used for batched mob rewards; the caller's scheduled flush persists the dirty data. */
    public boolean addBalanceDeferred(UUID playerId, long amount) {
        if (playerId == null || amount <= 0L) return false;
        long current = getBalance(playerId);
        if (current > Long.MAX_VALUE - amount) return false;
        playerData.set(balancePath(playerId), current + amount);
        markDirty.run();
        return true;
    }

    public void restoreSnapshot(String snapshot, String operation) {
        restore(snapshot, operation);
    }

    private void restore(String snapshot, String operation) {
        try {
            playerData.loadFromString(snapshot);
        } catch (InvalidConfigurationException exception) {
            logger.accept("Could not roll back " + operation + ": " + exception.getMessage());
        } finally {
            markDirty.run();
        }
    }

    private static String balancePath(UUID playerId) {
        return "players." + playerId + ".balance";
    }
}
