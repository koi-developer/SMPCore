package me.ren.smpcore.storage;

import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** Facade for persistent snapshots and audit records. */
public final class StorageManager {
    private final BackupManager backupManager;
    private final AuditLogger auditLogger;

    public StorageManager(Path pluginFolder, Consumer<String> infoLogger, Consumer<String> warningLogger) {
        this.backupManager = new BackupManager(pluginFolder.resolve("backups"), infoLogger);
        this.auditLogger = new AuditLogger(pluginFolder.resolve("logs").resolve("audit.log"), warningLogger);
    }

    public BackupManager.BackupResult createSnapshot(Map<String, Path> sources, int retention) {
        return backupManager.createSnapshot(sources, retention);
    }

    public void audit(String action, UUID actor, UUID target, String details) {
        auditLogger.record(action, actor, target, details);
    }
}
