package me.ren.smpcore;

import me.ren.smpcore.storage.StorageManager;
import me.ren.smpcore.commands.MenuCommand;
import me.ren.smpcore.events.InventoryMenuListener;
import me.ren.smpcore.events.ChatInputListener;
import me.ren.smpcore.events.QuestGameplayListener;
import me.ren.smpcore.events.PlayerLifecycleListener;
import me.ren.smpcore.storage.AtomicFileWriter;
import me.ren.smpcore.config.ConfigManager;
import me.ren.smpcore.economy.EconomyManager;
import me.ren.smpcore.menu.MenuManager;
import me.ren.smpcore.menu.MenuManager.MenuHolder;
import me.ren.smpcore.player.PlayerManager;
import me.ren.smpcore.quest.QuestManager;
import me.ren.smpcore.teleport.TeleportManager;
import me.ren.smpcore.events.EventManager;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.function.Consumer;

public final class SMPCore extends JavaPlugin {

    private static final String PREFIX = "&8[&bSMP&fCore&8] &7";
    private static final int[] PAGE_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };
    private static final Pattern SAFE_NAME = Pattern.compile("[A-Za-z0-9_-]{1,16}");
    private static final int MAX_BROADCAST_LENGTH = 160;

    private File homesFile;
    private File warpsFile;
    private File playerSettingsFile;
    private File marketFile;
    private YamlConfiguration homes;
    private YamlConfiguration warps;
    private YamlConfiguration playerSettings;
    private YamlConfiguration market;
    private boolean playerSettingsDirty;
    private final Map<UUID, Long> onlinePlaytimeFlush = new HashMap<>();

    // Async chat events only read/write these concurrent maps. All Bukkit work is moved to the main thread.
    private final Map<UUID, PendingInput> pendingInputs = new ConcurrentHashMap<>();
    private final Map<UUID, Location> pendingWarpLocations = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> pendingPaymentTargets = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> pendingEconomyTargets = new ConcurrentHashMap<>();
    private final Map<UUID, ItemStack> pendingMarketItems = new ConcurrentHashMap<>();
    private final Set<UUID> processingInputs = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Scoreboard> playerScoreboards = new HashMap<>();
    private final Map<UUID, List<String>> scoreboardEntries = new HashMap<>();
    private BukkitTask scoreboardTask;
    private BukkitTask backupTask;
    private StorageManager storageManager;
    private ConfigManager configManager;
    private EconomyManager economyManager;
    private MenuManager menuManager;
    private PlayerManager playerManager;
    private EventManager eventManager;
    private QuestManager questManager;
    private TeleportManager teleportManager;

    // TPA state is only accessed on the server thread and is intentionally not persisted across restarts.
    private final Map<UUID, LinkedHashMap<UUID, Long>> incomingTpaRequests = new HashMap<>();
    private final Map<UUID, UUID> outgoingTpaRequests = new HashMap<>();
    private final Map<UUID, Long> tpaCooldowns = new HashMap<>();

    private enum Page { MAIN, PROFILE, HOMES, WARPS, KITS, SHOP, RULES, SETTINGS, ADMIN, PLAYERS, PAY_PLAYERS, REQUESTS, SERVER, ECONOMY_ADMIN, ECONOMY_ADMIN_PLAYER, STATS, LEADERBOARD, DAILY_REWARD, QUESTS, MARKET, MARKET_MINE }
    private enum PendingInput { CREATE_HOME, CREATE_WARP, BROADCAST, PAY_AMOUNT, ADMIN_SET_BALANCE, MARKET_PRICE }


    @Override
    public void onEnable() {
        saveDefaultConfig();
        configManager = new ConfigManager(this);
        configManager.applyDefaultsAndValidate();
        loadDataFiles();
        menuManager = new MenuManager();
        playerManager = new PlayerManager(playerSettings, () -> playerSettingsDirty = true);
        eventManager = new EventManager(this);
        economyManager = new EconomyManager(playerSettings,
                () -> getConfig().getLong("economy.starting-balance", 100L),
                this::savePlayerSettingsNow,
                () -> playerSettingsDirty = true,
                message -> getLogger().severe(message));
        storageManager = new StorageManager(getDataFolder().toPath(),
                message -> getLogger().info(message), message -> getLogger().warning(message));
        questManager = new QuestManager(getConfig(), playerSettings, economyManager,
                () -> playerSettingsDirty = true);
        teleportManager = new TeleportManager(homes, warps,
                () -> saveYaml(homes, homesFile), () -> saveYaml(warps, warpsFile),
                message -> getLogger().severe(message));

        if (getCommand("menu") == null) {
            getLogger().severe("Command /menu is missing from plugin.yml. Disabling SMPCore.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        getCommand("menu").setExecutor(new MenuCommand(this));
        eventManager.register(new InventoryMenuListener(this));
        eventManager.register(new ChatInputListener(this));
        eventManager.register(new QuestGameplayListener(this));
        eventManager.register(new PlayerLifecycleListener(this));
        migrateLegacyHomes();
        getServer().getScheduler().runTaskTimer(this, this::cleanupTpaRequests, 200L, 200L);
        getServer().getScheduler().runTaskTimer(this, this::flushPlayerSettings, 200L, 200L);
        getServer().getScheduler().runTaskTimer(this, this::flushOnlinePlaytime, 1200L, 1200L);
        scheduleScoreboardUpdates();
        scheduleAutomaticBackups();
        long now = System.currentTimeMillis();
        for (Player online : Bukkit.getOnlinePlayers()) {
            onlinePlaytimeFlush.put(online.getUniqueId(), now);
            playerManager.rememberName(online.getUniqueId(), online.getName());
            updateScoreboard(online);
        }
        getLogger().info("SMPCore 2.1.0 enabled. Open the interface with /menu.");
    }

    @Override
    public void onDisable() {
        if (scoreboardTask != null) {
            scoreboardTask.cancel();
            scoreboardTask = null;
        }
        if (backupTask != null) {
            backupTask.cancel();
            backupTask = null;
        }
        if (eventManager != null) eventManager.unregisterAll();
        flushOnlinePlaytime();
        for (Player player : Bukkit.getOnlinePlayers()) removeScoreboard(player);
        saveDataFiles();
        pendingInputs.clear();
        pendingWarpLocations.clear();
        pendingPaymentTargets.clear();
        pendingEconomyTargets.clear();
        pendingMarketItems.clear();
        processingInputs.clear();
        incomingTpaRequests.clear();
        outgoingTpaRequests.clear();
        tpaCooldowns.clear();
        onlinePlaytimeFlush.clear();
        playerScoreboards.clear();
        scoreboardEntries.clear();
    }

    private void scheduleScoreboardUpdates() {
        if (scoreboardTask != null) scoreboardTask.cancel();
        long period = Math.max(20L, getConfig().getLong("scoreboard.update-ticks", 40L));
        scoreboardTask = getServer().getScheduler().runTaskTimer(this, this::updateAllScoreboards, 40L, period);
    }

    private void scheduleAutomaticBackups() {
        if (backupTask != null) backupTask.cancel();
        backupTask = null;
        if (!getConfig().getBoolean("storage.auto-backup.enabled", true)) return;
        long intervalMinutes = Math.max(15L, getConfig().getLong("storage.auto-backup.interval-minutes", 360L));
        long intervalTicks = intervalMinutes * 60L * 20L;
        backupTask = getServer().getScheduler().runTaskTimer(this, () -> createStorageBackup(null, true), intervalTicks, intervalTicks);
    }

    private boolean createStorageBackup(Player requester, boolean automatic) {
        if (storageManager == null) return false;
        flushOnlinePlaytime();
        boolean homesSaved = saveYaml(homes, homesFile);
        boolean warpsSaved = saveYaml(warps, warpsFile);
        boolean marketSaved = saveYaml(market, marketFile);
        boolean playersSaved = savePlayerSettingsNow();
        if (!homesSaved || !warpsSaved || !marketSaved || !playersSaved) {
            String message = "Backup skipped because at least one data file could not be saved.";
            if (automatic) getLogger().severe(message);
            else if (requester != null) requester.sendMessage(color(PREFIX + "Backup cancelled: storage could not be saved safely."));
            return false;
        }

        Map<String, Path> files = Map.of(
                "config.yml", new File(getDataFolder(), "config.yml").toPath(),
                "homes.yml", homesFile.toPath(),
                "warps.yml", warpsFile.toPath(),
                "players.yml", playerSettingsFile.toPath(),
                "market.yml", marketFile.toPath(),
                "audit.log", new File(getDataFolder(), "logs/audit.log").toPath(),
                "audit.log.1", new File(getDataFolder(), "logs/audit.log.1").toPath()
        );
        int retention = Math.max(1, getConfig().getInt("storage.auto-backup.retention-count", 10));
        var result = storageManager.createSnapshot(files, retention);
        if (!result.success()) {
            if (!automatic && requester != null) requester.sendMessage(color(PREFIX + "Backup failed: " + result.message()));
            return false;
        }
        if (storageManager != null) {
            storageManager.audit("STORAGE_BACKUP", requester == null ? null : requester.getUniqueId(), null,
                    (automatic ? "automatic" : "manual") + " files=" + result.filesCopied());
        }
        if (!automatic && requester != null) {
            requester.sendMessage(color(PREFIX + "Backup created: &b" + result.directory().getFileName() + " &7(" + result.filesCopied() + " files)."));
            playSuccessSound(requester);
        }
        return true;
    }

    private void loadDataFiles() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Could not create plugin data folder.");
        }

        homesFile = new File(getDataFolder(), "homes.yml");
        warpsFile = new File(getDataFolder(), "warps.yml");
        playerSettingsFile = new File(getDataFolder(), "players.yml");
        marketFile = new File(getDataFolder(), "market.yml");

        createIfMissing(homesFile);
        createIfMissing(warpsFile);
        createIfMissing(playerSettingsFile);
        createIfMissing(marketFile);

        homes = YamlConfiguration.loadConfiguration(homesFile);
        warps = YamlConfiguration.loadConfiguration(warpsFile);
        playerSettings = YamlConfiguration.loadConfiguration(playerSettingsFile);
        market = YamlConfiguration.loadConfiguration(marketFile);
    }

    /** Converts the single-home layout used by 1.0.x/1.1.x into the named-home layout. */
    private void migrateLegacyHomes() {
        ConfigurationSection root = homes.getConfigurationSection("homes");
        if (root == null) return;
        boolean changed = false;
        for (String ownerId : root.getKeys(false)) {
            String legacyPath = "homes." + ownerId;
            if (!homes.contains(legacyPath + ".world")) continue;
            String defaultPath = legacyPath + ".default";
            if (!homes.contains(defaultPath + ".world")) {
                for (String key : List.of("world", "x", "y", "z", "yaw", "pitch")) {
                    if (homes.contains(legacyPath + "." + key)) {
                        homes.set(defaultPath + "." + key, homes.get(legacyPath + "." + key));
                    }
                }
            }
            for (String key : List.of("world", "x", "y", "z", "yaw", "pitch")) {
                homes.set(legacyPath + "." + key, null);
            }
            changed = true;
        }
        if (changed) saveYaml(homes, homesFile);
    }

    private void createIfMissing(File file) {
        try {
            if (!file.exists() && !file.createNewFile()) {
                getLogger().warning("Could not create " + file.getName());
            }
        } catch (Exception exception) {
            getLogger().severe("Could not create " + file.getName() + ": " + exception.getMessage());
        }
    }

    private void saveDataFiles() {
        saveYaml(homes, homesFile);
        saveYaml(warps, warpsFile);
        saveYaml(market, marketFile);
        savePlayerSettingsNow();
    }

    private boolean savePlayerSettingsNow() {
        if (saveYaml(playerSettings, playerSettingsFile)) {
            playerSettingsDirty = false;
            return true;
        }
        return false;
    }

    private void flushPlayerSettings() {
        if (playerSettingsDirty) savePlayerSettingsNow();
    }

    private void restoreYamlSnapshot(YamlConfiguration target, String snapshot, String operation) {
        try {
            target.loadFromString(snapshot);
        } catch (InvalidConfigurationException exception) {
            getLogger().severe("Could not roll back " + operation + ": " + exception.getMessage());
        }
    }

    private boolean saveYaml(YamlConfiguration yaml, File file) {
        if (yaml == null || file == null) return false;
        return AtomicFileWriter.write(file.toPath(), temporary -> yaml.save(temporary.toFile()),
                message -> getLogger().severe("Could not save " + file.getName() + ": " + message));
    }

    /** Entry point used by MenuCommand; kept public for the command adapter. */
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(color(PREFIX + "Only players can open the menu."));
            return true;
        }
        if (!player.hasPermission("smpcore.use")) {
            player.sendMessage(color(PREFIX + "You do not have permission to open this menu."));
            return true;
        }
        if (pendingInputs.containsKey(player.getUniqueId())) {
            clearPendingInput(player.getUniqueId());
            player.sendMessage(color(PREFIX + "Pending chat input cancelled."));
        }
        openMainMenu(player);
        return true;
    }

    // ---------------------------------------------------------------------
    // Menu construction
    // ---------------------------------------------------------------------

    private Inventory createMenu(Player player, Page page, int pageIndex, String title) {
        return menuManager.createMenu(player, page, pageIndex, title, this::color,
                () -> item(Material.BLACK_STAINED_GLASS_PANE, "&0."));
    }

    private void openMainMenu(Player player) {
        Inventory inventory = createMenu(player, Page.MAIN, 0, "&8✦ &bSMP &fCORE &8✦");
        inventory.setItem(10, playerHead(player, "&bYour Profile", "&7View your player information", "", "&eClick to open"));
        inventory.setItem(12, item(Material.CHEST, "&aHomes", "&7Manage your personal home", "", "&eClick to open"));
        inventory.setItem(14, item(Material.COMPASS, "&bWarps", "&7Explore server destinations", "", "&eClick to open"));
        inventory.setItem(16, item(Material.BEACON, "&dSpawn", "&7Return to the server spawn", "", "&eClick to teleport"));
        inventory.setItem(20, item(Material.CHEST_MINECART, "&6Kits", "&7Claim server starter kits", "", "&eClick to browse"));
        if (getConfig().getBoolean("shop.enabled", true) && getConfig().getBoolean("economy.enabled", true)) {
            inventory.setItem(24, item(Material.EMERALD, "&aServer Shop", "&7Spend your coins on useful items", "&7Balance: &f" + formatCoins(getBalance(player.getUniqueId())), "", "&eClick to browse"));
            inventory.setItem(26, item(Material.GOLD_INGOT, "&6Pay a Player", "&7Send coins to another player", "&7Balance: &f" + formatCoins(getBalance(player.getUniqueId())), "", "&eClick to pay"));
            inventory.setItem(38, item(Material.SUNFLOWER, "&eYour Wallet", "&7Available balance: &f" + formatCoins(getBalance(player.getUniqueId())), "&7Earn coins from configured mob rewards."));
        } else {
            inventory.setItem(38, item(Material.GRAY_DYE, "&7Economy Disabled", "&7The server economy is currently disabled."));
        }
        inventory.setItem(37, item(Material.PLAYER_HEAD, "&bPlayer Statistics", "&7Your playtime, kills and deaths", "", "&eClick to view"));
        inventory.setItem(39, item(Material.GOLDEN_HELMET, "&6Leaderboards", "&7Top players on this server", "&7Coins, mob kills and playtime", "", "&eClick to view"));
        boolean dailyEnabled = getConfig().getBoolean("daily-rewards.enabled", true)
                && getConfig().getBoolean("economy.enabled", true) && getDailyRewardAmount() > 0L;
        boolean dailyClaimed = hasClaimedDailyReward(player.getUniqueId());
        inventory.setItem(41, item(dailyEnabled && !dailyClaimed ? Material.SUNFLOWER : Material.GRAY_DYE,
                "&eDaily Reward", dailyEnabled ? (dailyClaimed ? "&7Already claimed today" : "&aReady to claim") : "&cDaily rewards are disabled.",
                "&7Reward: &6" + formatCoins(getDailyRewardAmount()), "", "&eClick to view"));
        inventory.setItem(28, item(Material.WRITTEN_BOOK, "&eServer Rules", "&7Read the server guidelines", "", "&eClick to view"));
        inventory.setItem(30, item(Material.PLAYER_HEAD, "&bOnline Players", "&7Find players and request a teleport", "", "&eClick to browse"));
        int requestCount = getIncomingRequestCount(player.getUniqueId());
        inventory.setItem(32, item(requestCount > 0 ? Material.WRITABLE_BOOK : Material.BOOK,
                requestCount > 0 ? "&aTeleport Requests &8(&f" + requestCount + "&8)" : "&7Teleport Requests",
                "&7Accept or decline incoming requests", "", "&eClick to open"));
        inventory.setItem(33, item(Material.WRITABLE_BOOK, "&aQuest Journal", "&7Complete objectives for coin rewards", "", "&eClick to view"));
        inventory.setItem(34, enchantedItem(Material.AMETHYST_SHARD, "&dSettings", "&7Personal menu preferences", "", "&eClick to open"));
        inventory.setItem(40, item(Material.NETHER_STAR, "&6SMPCore", "&7A clean and simple SMP menu", "&8Version " + getDescription().getVersion(), "&7Online: &f" + Bukkit.getOnlinePlayers().size() + "&7/&f" + Bukkit.getMaxPlayers()));
        inventory.setItem(42, item(Material.BARREL, "&6Player Market", "&7Buy and sell player-listed items", "&7Fixed prices • No bidding", "", "&eClick to browse"));
        inventory.setItem(43, item(Material.LECTERN, "&eServer Information", "&7View server details and status", "", "&eClick to view"));

        if (player.hasPermission("smpcore.admin")) {
            inventory.setItem(22, enchantedItem(Material.COMMAND_BLOCK, "&cAdmin Panel", "&7Server management tools", "", "&eClick to open"));
        }

        player.openInventory(inventory);
        playOpenSound(player);
    }

    private void openProfileMenu(Player player) {
        Inventory inventory = createMenu(player, Page.PROFILE, 0, "&8Your Profile");
        inventory.setItem(22, playerHead(player,
                "&b" + player.getName(),
                "&7UUID: &f" + player.getUniqueId(),
                "&7World: &f" + player.getWorld().getName(),
                "&7Position: &f" + player.getLocation().getBlockX() + ", " + player.getLocation().getBlockY() + ", " + player.getLocation().getBlockZ(),
                "&7Level: &f" + player.getLevel(),
                "&7Health: &f" + Math.round(player.getHealth()) + "/" + Math.round(player.getMaxHealth()),
                "&7Food: &f" + player.getFoodLevel(),
                "&7Balance: &f" + formatCoins(getBalance(player.getUniqueId()))));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openStatsMenu(Player player) {
        UUID id = player.getUniqueId();
        long playtime = getStat(id, "playtime-seconds");
        long mobKills = getStat(id, "mob-kills");
        long playerKills = getStat(id, "player-kills");
        long deaths = getStat(id, "deaths");
        Inventory inventory = createMenu(player, Page.STATS, 0, "&8Your Statistics");
        if (!getConfig().getBoolean("stats.enabled", true)) {
            inventory.setItem(22, item(Material.BARRIER, "&cStatistics Disabled", "&7Statistics tracking is disabled by the server."));
        } else {
            inventory.setItem(20, item(Material.CLOCK, "&bPlaytime", "&7Total time played", "&f" + formatPlaytime(playtime)));
            inventory.setItem(22, item(Material.IRON_SWORD, "&aMob Kills", "&7Mobs defeated", "&f" + mobKills));
            inventory.setItem(24, item(Material.DIAMOND_SWORD, "&cPlayer Kills", "&7Player eliminations", "&f" + playerKills));
            inventory.setItem(31, item(Material.TOTEM_OF_UNDYING, "&eDeaths", "&7Times you have died", "&f" + deaths));
        }
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openLeaderboardMenu(Player player) {
        Inventory inventory = createMenu(player, Page.LEADERBOARD, 0, "&8SMP Leaderboards");
        inventory.setItem(11, item(Material.GOLD_INGOT, "&6Top Balances", "&7Highest coin balances"));
        inventory.setItem(13, item(Material.IRON_SWORD, "&aTop Mob Kills", "&7Most mobs defeated"));
        inventory.setItem(15, item(Material.CLOCK, "&bTop Playtime", "&7Longest time played"));
        List<UUID> ids = getStoredPlayerIds();
        renderLeaderboardColumn(inventory, ids, "balance", 0, "coins");
        renderLeaderboardColumn(inventory, ids, "stats.mob-kills", 1, "kills");
        renderLeaderboardColumn(inventory, ids, "stats.playtime-seconds", 2, "seconds");
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void renderLeaderboardColumn(Inventory inventory, List<UUID> ids, String key, int column, String valueType) {
        List<UUID> ranked = new ArrayList<>(ids);
        ranked.sort(Comparator.comparingLong((UUID id) -> getPlayerValue(id, key)).reversed());
        int[] rows = {20, 29, 38};
        for (int i = 0; i < Math.min(3, ranked.size()); i++) {
            UUID id = ranked.get(i);
            String name = playerManager.getPlayerName(id, id.toString().substring(0, 8));
            long value = getPlayerValue(id, key);
            String displayValue = valueType.equals("coins") ? formatCoins(value)
                    : valueType.equals("seconds") ? formatPlaytime(value) : String.format(Locale.US, "%,d", value);
            int slot = rows[i] + column * 2;
            inventory.setItem(slot, item(i == 0 ? Material.PLAYER_HEAD : Material.PAPER,
                    "&f#" + (i + 1) + " &b" + name,
                    "&7" + displayValue));
        }
    }

    private void openDailyRewardMenu(Player player) {
        Inventory inventory = createMenu(player, Page.DAILY_REWARD, 0, "&8Daily Reward");
        long amount = getDailyRewardAmount();
        boolean enabled = getConfig().getBoolean("daily-rewards.enabled", true)
                && getConfig().getBoolean("economy.enabled", true) && amount > 0L;
        boolean claimed = hasClaimedDailyReward(player.getUniqueId());
        inventory.setItem(22, item(enabled && !claimed ? Material.SUNFLOWER : Material.GRAY_DYE,
                enabled && !claimed ? "&aClaim Daily Reward" : "&7Daily Reward Unavailable",
                "&7Reward: &6" + formatCoins(amount),
                claimed ? "&cYou have already claimed today's reward." : "&7One claim per configured calendar day.",
                enabled && !claimed ? "" : "&8Not available", "", enabled && !claimed ? "&eClick to claim" : "&7Come back later"));
        String claimStatus = !enabled ? "&cDisabled" : claimed ? "&cClaimed" : "&aAvailable";
        inventory.setItem(31, item(Material.CLOCK, "&bDaily Reset", "&7Timezone: &f" + getDailyRewardZone().getId(),
                "&7Claim status: " + claimStatus));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private List<UUID> getStoredPlayerIds() {
        return playerManager.getStoredPlayerIds();
    }

    private long getPlayerValue(UUID id, String key) {
        return playerManager.getPlayerValue(id, key);
    }

    private long getStat(UUID id, String key) {
        return playerManager.getStat(id, key);
    }

    private void incrementStat(UUID id, String key, long amount) {
        playerManager.incrementStat(id, key, amount, getConfig().getBoolean("stats.enabled", true));
    }

    private String formatPlaytime(long seconds) {
        return playerManager.formatPlaytime(seconds);
    }

    private ZoneId getDailyRewardZone() {
        String configured = getConfig().getString("daily-rewards.timezone", "Asia/Yangon");
        try { return ZoneId.of(configured == null ? "Asia/Yangon" : configured); }
        catch (DateTimeException exception) {
            getLogger().warning("Invalid daily-rewards.timezone; falling back to Asia/Yangon.");
            return ZoneId.of("Asia/Yangon");
        }
    }

    private String getDailyRewardDateKey() {
        return LocalDate.now(getDailyRewardZone()).format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    private long getDailyRewardAmount() {
        return Math.max(0L, getConfig().getLong("daily-rewards.amount", 100L));
    }

    private boolean hasClaimedDailyReward(UUID id) {
        return getDailyRewardDateKey().equals(playerSettings.getString("players." + id + ".daily.last-claim", ""));
    }

    private void claimDailyReward(Player player) {
        UUID id = player.getUniqueId();
        if (!getConfig().getBoolean("daily-rewards.enabled", true) || !getConfig().getBoolean("economy.enabled", true)) {
            player.sendMessage(color(PREFIX + "Daily rewards are currently disabled."));
            openDailyRewardMenu(player);
            return;
        }
        if (hasClaimedDailyReward(id)) {
            player.sendMessage(color(PREFIX + "You have already claimed today's daily reward."));
            openDailyRewardMenu(player);
            return;
        }
        long amount = getDailyRewardAmount();
        long balance = getBalance(id);
        if (amount <= 0L || balance > Long.MAX_VALUE - amount) {
            player.sendMessage(color(PREFIX + "The daily reward is not configured correctly or your wallet is full."));
            return;
        }
        String snapshot = playerSettings.saveToString();
        playerSettings.set("players." + id + ".balance", balance + amount);
        playerSettings.set("players." + id + ".daily.last-claim", getDailyRewardDateKey());
        if (!savePlayerSettingsNow()) {
            restorePlayerSettingsSnapshot(snapshot, "daily reward");
            player.sendMessage(color(PREFIX + "The reward could not be saved. No reward was claimed; please try again."));
            return;
        }
        if (storageManager != null) storageManager.audit("DAILY_REWARD", id, null, "amount=" + amount);
        player.sendMessage(color(PREFIX + "Daily reward claimed: &6+" + formatCoins(amount) + "&7."));
        playSuccessSound(player);
        openDailyRewardMenu(player);
    }

    private void flushOnlinePlaytime() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : new ArrayList<>(onlinePlaytimeFlush.entrySet())) {
            long previous = entry.getValue();
            long elapsedSeconds = Math.max(0L, (now - previous) / 1000L);
            if (elapsedSeconds <= 0L) continue;
            if (getConfig().getBoolean("stats.enabled", true)) {
                incrementStat(entry.getKey(), "playtime-seconds", elapsedSeconds);
            }
            incrementQuestProgress(entry.getKey(), "PLAYTIME_SECONDS", elapsedSeconds);
            onlinePlaytimeFlush.put(entry.getKey(), previous + elapsedSeconds * 1000L);
        }
    }

    private void flushPlayerSession(UUID playerId) {
        Long previous = onlinePlaytimeFlush.remove(playerId);
        if (previous == null) return;
        long elapsedSeconds = Math.max(0L, (System.currentTimeMillis() - previous) / 1000L);
        if (getConfig().getBoolean("stats.enabled", true)) {
            incrementStat(playerId, "playtime-seconds", elapsedSeconds);
        }
        incrementQuestProgress(playerId, "PLAYTIME_SECONDS", elapsedSeconds);
        savePlayerSettingsNow();
    }

    private void openQuestsMenu(Player player, int pageIndex) {
        List<String> questNames = questManager.getEnabledQuestKeys();
        int maxPage = Math.max(0, (questNames.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.QUESTS, safePage, "&8Quest Journal &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(questNames);
        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < questNames.size(); i++) {
            String key = questNames.get(start + i);
            QuestManager.QuestView quest = questManager.getQuest(player.getUniqueId(), key);
            if (quest == null) continue;
            String state = quest.claimed() ? "&aReward claimed"
                    : quest.progress() >= quest.target() ? "&eReady to claim" : "&7In progress";
            inventory.setItem(PAGE_SLOTS[i], item(quest.icon(), quest.displayName(),
                    "&7" + quest.description(),
                    "&7Progress: &f" + quest.progress() + "/" + quest.target(),
                    "&7Reward: &6" + formatCoins(quest.reward()), state, "",
                    quest.claimed() ? "&8Already claimed" : "&eClick to claim reward"));
        }
        if (questNames.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cNo Quests Available", "&7Quests are disabled or not configured."));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openMarketMenu(Player player, int pageIndex) {
        boolean marketEnabled = getConfig().getBoolean("market.enabled", true)
                && getConfig().getBoolean("economy.enabled", true);
        List<String> listings = marketEnabled ? getMarketListingIds(false, null) : new ArrayList<>();
        int maxPage = Math.max(0, (listings.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.MARKET, safePage, "&8Player Market &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(listings);
        inventory.setItem(4, item(Material.GOLD_INGOT, "&eYour Wallet", "&7Balance: &6" + formatCoins(getBalance(player.getUniqueId()))));
        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < listings.size(); i++) {
            String id = listings.get(start + i);
            ItemStack listed = market.getItemStack("listings." + id + ".item");
            long price = market.getLong("listings." + id + ".price", -1L);
            String seller = market.getString("listings." + id + ".seller-name", "Unknown");
            if (listed == null || listed.getType().isAir() || price <= 0L || !isMarketMaterialAllowed(listed.getType())) {
                inventory.setItem(PAGE_SLOTS[i], item(Material.BARRIER, "&cUnavailable Listing", "&7This listing is invalid."));
                continue;
            }
            ItemStack display = listed.clone();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
                lore.add(color("&7Seller: &f" + seller));
                lore.add(color("&7Price: &6" + formatCoins(price)));
                lore.add(color("&eClick to purchase"));
                meta.setLore(lore);
                display.setItemMeta(meta);
            }
            inventory.setItem(PAGE_SLOTS[i], display);
        }
        if (!marketEnabled) inventory.setItem(22, item(Material.BARRIER, "&cMarket Disabled", "&7The market or economy is disabled by the server."));
        else if (listings.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cMarket is Empty", "&7Be the first player to list an item."));
        inventory.setItem(45, item(Material.SUNFLOWER, "&aSell Main-Hand Item", "&7Create a fixed-price listing", "&7Your held item stack will be listed.", "", "&eClick to list"));
        inventory.setItem(53, item(Material.CHEST, "&bMy Listings", "&7View or cancel your listings", "", "&eClick to open"));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openMyMarketMenu(Player player, int pageIndex) {
        List<String> listings = getMarketListingIds(true, player.getUniqueId());
        int maxPage = Math.max(0, (listings.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.MARKET_MINE, safePage, "&8My Listings &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(listings);
        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < listings.size(); i++) {
            String id = listings.get(start + i);
            ItemStack listed = market.getItemStack("listings." + id + ".item");
            if (listed == null) continue;
            ItemStack display = listed.clone();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
                lore.add(color("&7Price: &6" + formatCoins(market.getLong("listings." + id + ".price", 0L))));
                lore.add(color("&eClick to cancel and reclaim"));
                meta.setLore(lore);
                display.setItemMeta(meta);
            }
            inventory.setItem(PAGE_SLOTS[i], display);
        }
        if (listings.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cNo Active Listings", "&7You have not listed any items."));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, item(Material.ARROW, "&cBack to Market"));
        player.openInventory(inventory);
    }

    private List<String> getMarketListingIds(boolean ownOnly, UUID owner) {
        ConfigurationSection root = market.getConfigurationSection("listings");
        if (root == null) return new ArrayList<>();
        List<String> ids = new ArrayList<>();
        for (String id : root.getKeys(false)) {
            if (ownOnly && !String.valueOf(owner).equals(market.getString("listings." + id + ".seller"))) continue;
            ItemStack listed = market.getItemStack("listings." + id + ".item");
            if (listed == null || !isMarketMaterialAllowed(listed.getType())) continue;
            ids.add(id);
        }
        ids.sort(Comparator.comparingLong((String id) -> market.getLong("listings." + id + ".created", 0L)).reversed());
        return ids;
    }

    private boolean isMarketMaterialAllowed(Material material) {
        String name = material.name();
        return !name.endsWith("_SWORD") && !name.endsWith("_AXE")
                && !name.endsWith("_HELMET") && !name.endsWith("_CHESTPLATE")
                && !name.endsWith("_LEGGINGS") && !name.endsWith("_BOOTS")
                && !name.equals("BOW") && !name.equals("CROSSBOW")
                && !name.equals("TRIDENT") && !name.equals("MACE")
                && !name.equals("SHIELD") && !name.equals("ENCHANTED_BOOK")
                && !name.contains("ARROW");
    }

    private void startMarketListing(Player player) {
        if (!getConfig().getBoolean("market.enabled", true) || !getConfig().getBoolean("economy.enabled", true)) {
            player.sendMessage(color(PREFIX + "The player market is currently disabled."));
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            player.sendMessage(color(PREFIX + "Hold the item you want to list in your main hand."));
            return;
        }
        if (!isMarketMaterialAllowed(hand.getType())) {
            player.sendMessage(color(PREFIX + "This market is for building, farming and utility items only."));
            return;
        }
        int maxListings = Math.max(1, getConfig().getInt("market.max-listings-per-player", 5));
        if (getMarketListingIds(true, player.getUniqueId()).size() >= maxListings) {
            player.sendMessage(color(PREFIX + "You have reached your listing limit (&b" + maxListings + "&7)."));
            return;
        }
        pendingMarketItems.put(player.getUniqueId(), hand.clone());
        pendingInputs.put(player.getUniqueId(), PendingInput.MARKET_PRICE);
        player.closeInventory();
        player.sendMessage(color(PREFIX + "Enter a whole-number price for your held item stack."));
        player.sendMessage(color("&7Maximum price: &6" + formatCoins(Math.max(1L, getConfig().getLong("market.max-price", 1000000000L))) + "&7. Type &ccancel &7 to stop."));
    }

    private void claimQuest(Player player, String key, int pageIndex) {
        QuestManager.ClaimResult result = questManager.claim(player.getUniqueId(), key);
        switch (result.status()) {
            case CLAIMED -> {
                if (storageManager != null) storageManager.audit("QUEST_REWARD", player.getUniqueId(), null,
                        "quest=" + key + " amount=" + result.reward());
                player.sendMessage(color(PREFIX + "Quest completed: &b" + result.displayName()
                        + " &7— reward &6+" + formatCoins(result.reward()) + "&7."));
                playSuccessSound(player);
                openQuestsMenu(player, pageIndex);
            }
            case DISABLED -> {
                player.sendMessage(color(PREFIX + "Quests or the economy are currently disabled."));
                openQuestsMenu(player, pageIndex);
            }
            case UNKNOWN_QUEST -> openQuestsMenu(player, pageIndex);
            case ALREADY_CLAIMED -> {
                player.sendMessage(color(PREFIX + "You have already claimed this quest reward."));
                openQuestsMenu(player, pageIndex);
            }
            case INCOMPLETE -> {
                QuestManager.QuestView quest = questManager.getQuest(player.getUniqueId(), key);
                if (quest != null) player.sendMessage(color(PREFIX + "This quest is not complete yet (&b"
                        + quest.progress() + "/" + quest.target() + "&7)."));
            }
            case INVALID_REWARD -> player.sendMessage(color(PREFIX + "This quest reward is unavailable."));
            case WALLET_FULL -> player.sendMessage(color(PREFIX + "Your wallet cannot receive this reward."));
            case SAVE_FAILED -> player.sendMessage(color(PREFIX + "The reward could not be saved. It remains available to claim."));
        }
    }

    private void incrementQuestProgress(UUID playerId, String objectiveType, long amount) {
        for (String displayName : questManager.incrementProgress(playerId, objectiveType, amount)) {
            Player online = Bukkit.getPlayer(playerId);
            if (online != null) online.sendMessage(color(PREFIX + "Quest ready to claim: &b"
                    + displayName + "&7. Open &e/menu &7> Quest Journal."));
        }
    }

    private void purchaseMarketListing(Player buyer, String id, int pageIndex) {
        if (!getConfig().getBoolean("market.enabled", true) || !getConfig().getBoolean("economy.enabled", true)) {
            buyer.sendMessage(color(PREFIX + "The player market is currently disabled."));
            return;
        }
        String path = "listings." + id;
        if (!market.contains(path + ".seller")) return;
        UUID sellerId;
        try {
            sellerId = UUID.fromString(market.getString(path + ".seller", ""));
        } catch (IllegalArgumentException exception) {
            buyer.sendMessage(color(PREFIX + "This listing is invalid."));
            return;
        }
        if (sellerId.equals(buyer.getUniqueId())) {
            buyer.sendMessage(color(PREFIX + "You cannot purchase your own listing."));
            return;
        }
        ItemStack listed = market.getItemStack(path + ".item");
        long price = market.getLong(path + ".price", -1L);
        long maximum = Math.max(1L, getConfig().getLong("market.max-price", 1000000000L));
        if (listed == null || listed.getType().isAir() || price <= 0L || price > maximum
                || !isMarketMaterialAllowed(listed.getType())) {
            buyer.sendMessage(color(PREFIX + "This listing is unavailable or invalid."));
            return;
        }
        if (hasOverflow(List.of(listed.clone()), buyer.getInventory().getStorageContents())) {
            buyer.sendMessage(color(PREFIX + "Your inventory does not have enough room for this item."));
            return;
        }
        long buyerBalance = getBalance(buyer.getUniqueId());
        long sellerBalance = getBalance(sellerId);
        if (buyerBalance < price) {
            buyer.sendMessage(color(PREFIX + "You need &6" + formatCoins(price - buyerBalance) + " &7more to buy this."));
            return;
        }
        if (sellerBalance > Long.MAX_VALUE - price) {
            buyer.sendMessage(color(PREFIX + "The seller's wallet cannot receive this payment."));
            return;
        }

        // Commit both YAML files before delivering the item. If either write fails,
        // restore both snapshots so a failed transaction cannot consume or duplicate a listing.
        if (!commitMarketSale(path, buyer.getUniqueId(), buyerBalance - price, sellerId,
                sellerBalance + price, market.getString(path + ".seller-name", "Unknown"))) {
            buyer.sendMessage(color(PREFIX + "The purchase could not be saved. No money or item was transferred."));
            return;
        }

        Map<Integer, ItemStack> leftovers = buyer.getInventory().addItem(listed.clone());
        if (!leftovers.isEmpty()) {
            // Defensive fallback: the inventory was checked immediately before commit.
            // Drop only the uninserted remainder; the buyer has already paid for the listing.
            for (ItemStack leftover : leftovers.values()) {
                buyer.getWorld().dropItemNaturally(buyer.getLocation(), leftover);
            }
            buyer.sendMessage(color(PREFIX + "The purchase completed; remaining items were dropped beside you."));
        } else {
            buyer.sendMessage(color(PREFIX + "Purchased the listing for &6" + formatCoins(price) + "&7."));
        }
        if (storageManager != null) storageManager.audit("MARKET_PURCHASE", buyer.getUniqueId(), sellerId, "listing=" + id + " price=" + price + " item=" + listed.getType().name() + " amount=" + listed.getAmount());
        Player seller = Bukkit.getPlayer(sellerId);
        if (seller != null) seller.sendMessage(color(PREFIX + "Your market listing sold for &6" + formatCoins(price) + "&7."));
        playSuccessSound(buyer);
        openMarketMenu(buyer, pageIndex);
    }

    private boolean commitMarketSale(String listingPath, UUID buyerId, long buyerBalance,
                                     UUID sellerId, long sellerBalance, String sellerName) {
        String previousMarket = market.saveToString();
        String previousPlayers = playerSettings.saveToString();

        market.set(listingPath, null);
        playerSettings.set("players." + buyerId + ".balance", buyerBalance);
        playerSettings.set("players." + sellerId + ".balance", sellerBalance);
        playerManager.rememberName(sellerId, sellerName);

        if (!saveYaml(market, marketFile)) {
            restoreMarketTransaction(previousMarket, previousPlayers);
            return false;
        }
        if (!saveYaml(playerSettings, playerSettingsFile)) {
            restoreMarketTransaction(previousMarket, previousPlayers);
            return false;
        }
        playerSettingsDirty = false;
        return true;
    }

    private void restoreMarketTransaction(String previousMarket, String previousPlayers) {
        try {
            market.loadFromString(previousMarket);
            playerSettings.loadFromString(previousPlayers);
            boolean marketRestored = saveYaml(market, marketFile);
            boolean playersRestored = saveYaml(playerSettings, playerSettingsFile);
            playerSettingsDirty = !playersRestored;
            if (!marketRestored || !playersRestored) {
                getLogger().severe("Market transaction rollback could not be fully persisted. Restore from the latest backup before reopening the market.");
            }
        } catch (InvalidConfigurationException exception) {
            getLogger().severe("Market transaction rollback failed while restoring YAML snapshots: " + exception.getMessage());
        }
    }

    private void cancelMarketListing(Player player, String id, int pageIndex) {
        String path = "listings." + id;
        if (!String.valueOf(player.getUniqueId()).equals(market.getString(path + ".seller", ""))) return;
        ItemStack listed = market.getItemStack(path + ".item");
        if (listed == null || listed.getType().isAir()) return;
        if (hasOverflow(List.of(listed.clone()), player.getInventory().getStorageContents())) {
            player.sendMessage(color(PREFIX + "Make room in your inventory before reclaiming this listing."));
            return;
        }

        String previousMarket = market.saveToString();
        market.set(path, null);
        if (!saveYaml(market, marketFile)) {
            try {
                market.loadFromString(previousMarket);
            } catch (InvalidConfigurationException exception) {
                getLogger().severe("Could not restore a market listing after a failed cancellation: " + exception.getMessage());
            }
            player.sendMessage(color(PREFIX + "The listing could not be cancelled because storage failed. Your item remains listed."));
            return;
        }

        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(listed.clone());
        if (!leftovers.isEmpty()) {
            for (ItemStack leftover : leftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
        }
        if (storageManager != null) storageManager.audit("MARKET_CANCEL", player.getUniqueId(), null, "listing=" + id + " item=" + listed.getType().name() + " amount=" + listed.getAmount());
        player.sendMessage(color(PREFIX + "Listing cancelled and item reclaimed."));
        playSuccessSound(player);
        openMyMarketMenu(player, pageIndex);
    }

    private void openHomesMenu(Player player, int pageIndex) {
        List<String> names = getHomeNames(player.getUniqueId());
        int maxPage = Math.max(0, (names.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.HOMES, safePage, "&8Your Homes &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(names);

        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < names.size(); i++) {
            String name = names.get(start + i);
            Location home = getHome(player.getUniqueId(), name);
            if (home == null) {
                inventory.setItem(PAGE_SLOTS[i], item(Material.BARRIER, "&c" + name, "&7World is not currently loaded."));
                continue;
            }
            inventory.setItem(PAGE_SLOTS[i], item(Material.RED_BED, "&a" + name,
                    "&7World: &f" + home.getWorld().getName(),
                    "&7X: &f" + home.getBlockX() + "  &7Y: &f" + home.getBlockY() + "  &7Z: &f" + home.getBlockZ(),
                    "", "&eLeft-click: teleport", "&cRight-click: delete"));
        }
        int maxHomes = getMaxHomes(player);
        inventory.setItem(45, item(names.size() < maxHomes ? Material.LIME_BED : Material.GRAY_BED,
                "&aCreate Home", "&7Homes: &f" + names.size() + "&7/&f" + maxHomes,
                names.size() < maxHomes ? "" : "&cYou have reached your limit.", "", "&eClick to create"));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        if (names.isEmpty()) inventory.setItem(22, item(Material.GRAY_BED, "&7No Homes Yet", "&7Use Create Home to save a location."));
        player.openInventory(inventory);
    }

    private void openKitsMenu(Player player, int pageIndex) {
        ConfigurationSection root = getConfig().getConfigurationSection("kits");
        List<String> kitNames = new ArrayList<>();
        if (root != null && getConfig().getBoolean("kits.enabled", true)) {
            kitNames.addAll(root.getKeys(false));
            kitNames.removeIf(name -> name.equalsIgnoreCase("enabled") || root.getConfigurationSection(name) == null);
        }
        kitNames.sort(String.CASE_INSENSITIVE_ORDER);
        int maxPage = Math.max(0, (kitNames.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.KITS, safePage, "&8Server Kits &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(kitNames);

        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < kitNames.size(); i++) {
            String name = kitNames.get(start + i);
            ConfigurationSection kit = root.getConfigurationSection(name);
            String iconName = kit.getString("icon", "CHEST");
            Material icon = Material.matchMaterial(iconName == null ? "CHEST" : iconName);
            if (icon == null || !icon.isItem()) icon = Material.CHEST;
            String permission = kit.getString("permission", "");
            long readyAt = playerSettings.getLong("players." + player.getUniqueId() + ".kit-cooldowns." + name, 0L);
            long remaining = Math.max(0L, readyAt - System.currentTimeMillis());
            boolean allowed = permission == null || permission.isBlank() || player.hasPermission(permission);
            String state = !allowed ? "&cNo permission" : remaining > 0 ? "&eAvailable in: &f" + formatDuration(remaining) : "&aReady to claim";
            String display = kit.getString("display-name", name);
            inventory.setItem(PAGE_SLOTS[i], item(icon, display,
                    "&7Kit: &f" + name, state, "", "&eClick to claim"));
        }
        if (kitNames.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cNo Kits Available", "&7Kits are disabled or not configured."));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openShopMenu(Player player, int pageIndex) {
        ConfigurationSection root = getConfig().getConfigurationSection("shop");
        List<String> products = new ArrayList<>();
        if (root != null && getConfig().getBoolean("shop.enabled", true) && getConfig().getBoolean("economy.enabled", true)) {
            products.addAll(root.getKeys(false));
            products.removeIf(name -> name.equalsIgnoreCase("enabled") || root.getConfigurationSection(name) == null);
        }
        products.sort(String.CASE_INSENSITIVE_ORDER);
        int maxPage = Math.max(0, (products.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.SHOP, safePage, "&8Server Shop &7• &f" + (safePage + 1));
        MenuHolder holder = (MenuHolder) inventory.getHolder();
        holder.setEntries(products);
        inventory.setItem(4, item(Material.SUNFLOWER, "&eYour Balance", "&7Wallet: &f" + formatCoins(getBalance(player.getUniqueId()))));

        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < products.size(); i++) {
            String key = products.get(start + i);
            ConfigurationSection product = root.getConfigurationSection(key);
            Material material = Material.matchMaterial(product.getString("material", "BREAD"));
            if (material == null || !material.isItem()) material = Material.BARRIER;
            int amount = Math.max(1, Math.min(2304, product.getInt("amount", 1)));
            long price = Math.max(0L, product.getLong("price", 0L));
            String permission = product.getString("permission", "");
            boolean allowed = permission == null || permission.isBlank() || player.hasPermission(permission);
            String displayName = product.getString("display-name", key);
            inventory.setItem(PAGE_SLOTS[i], item(material, displayName,
                    "&7Item: &f" + material.name() + " x" + amount,
                    "&7Price: &6" + formatCoins(price),
                    allowed ? "&aAvailable" : "&cNo permission",
                    "", "&eClick to purchase"));
        }
        if (products.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cShop Unavailable", "&7The shop is disabled or has no products configured."));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openPayPlayersMenu(Player viewer, int pageIndex) {
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        players.removeIf(target -> target.getUniqueId().equals(viewer.getUniqueId()));
        players.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        int maxPage = Math.max(0, (players.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(viewer, Page.PAY_PLAYERS, safePage, "&8Pay a Player &7• &f" + (safePage + 1));
        MenuHolder holder = (MenuHolder) inventory.getHolder();
        holder.setEntries(players.stream().map(target -> target.getUniqueId().toString()).toList());
        inventory.setItem(4, item(Material.SUNFLOWER, "&eYour Balance", "&7Wallet: &f" + formatCoins(getBalance(viewer.getUniqueId()))));
        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < players.size(); i++) {
            Player target = players.get(start + i);
            inventory.setItem(PAGE_SLOTS[i], playerHead(target, "&b" + target.getName(), "&7Click to send coins", "&7Your balance: &f" + formatCoins(getBalance(viewer.getUniqueId()))));
        }
        if (players.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cNo Other Players Online", "&7There is nobody to pay right now."));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        viewer.openInventory(inventory);
    }

    private void openAdminEconomyMenu(Player player, int pageIndex) {
        if (!player.hasPermission("smpcore.admin")) return;
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        players.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        int maxPage = Math.max(0, (players.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.ECONOMY_ADMIN, safePage, "&8Economy Manager &7• &f" + (safePage + 1));
        MenuHolder holder = (MenuHolder) inventory.getHolder();
        holder.setEntries(players.stream().map(target -> target.getUniqueId().toString()).toList());
        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < players.size(); i++) {
            Player target = players.get(start + i);
            inventory.setItem(PAGE_SLOTS[i], playerHead(target, "&b" + target.getName(), "&7Balance: &f" + formatCoins(getBalance(target.getUniqueId())), "", "&eClick to manage wallet"));
        }
        if (players.isEmpty()) inventory.setItem(22, item(Material.BARRIER, "&cNo Players Online", "&7No player wallets to manage."));
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openAdminEconomyPlayerMenu(Player admin, UUID targetId) {
        if (!admin.hasPermission("smpcore.admin")) return;
        Player target = Bukkit.getPlayer(targetId);
        String targetName = target == null ? targetId.toString().substring(0, 8) : target.getName();
        Inventory inventory = createMenu(admin, Page.ECONOMY_ADMIN_PLAYER, 0, "&8Wallet: &b" + targetName);
        ((MenuHolder) inventory.getHolder()).setEntries(List.of(targetId.toString()));
        inventory.setItem(20, item(Material.LIME_CONCRETE, "&aDeposit 100", "&7Add 100 coins to this wallet."));
        inventory.setItem(22, item(Material.RED_CONCRETE, "&cWithdraw 100", "&7Remove 100 coins from this wallet."));
        inventory.setItem(24, item(Material.NAME_TAG, "&eSet Balance", "&7Enter a new balance in chat.", "&7Use a whole number from 0 upward."));
        inventory.setItem(31, item(Material.SUNFLOWER, "&eCurrent Balance", "&7Player: &f" + targetName, "&7Balance: &6" + formatCoins(getBalance(targetId))));
        inventory.setItem(49, item(Material.ARROW, "&cBack to Players"));
        admin.openInventory(inventory);
    }

    private void openWarpsMenu(Player player, int pageIndex) {
        List<String> names = getWarpNames();
        int maxPage = Math.max(0, (names.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(player, Page.WARPS, safePage, "&8Server Warps &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(names);

        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < names.size(); i++) {
            String name = names.get(start + i);
            Location location = getWarp(name);
            if (location == null) {
                inventory.setItem(PAGE_SLOTS[i], item(Material.BARRIER, "&c" + name, "&7World is not currently loaded."));
                continue;
            }
            inventory.setItem(PAGE_SLOTS[i], item(Material.ENDER_PEARL, "&b" + name,
                    "&7World: &f" + location.getWorld().getName(),
                    "&7X: &f" + location.getBlockX() + "  &7Y: &f" + location.getBlockY() + "  &7Z: &f" + location.getBlockZ(),
                    "", "&eLeft-click: teleport",
                    player.hasPermission("smpcore.admin") ? "&cRight-click: delete warp" : "&7Server destination"));
        }

        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openPlayersMenu(Player viewer, int pageIndex) {
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        players.removeIf(target -> target.getUniqueId().equals(viewer.getUniqueId()));
        players.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));

        int maxPage = Math.max(0, (players.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(viewer, Page.PLAYERS, safePage, "&8Online Players &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(players.stream().map(target -> target.getUniqueId().toString()).toList());

        int start = safePage * PAGE_SLOTS.length;
        for (int i = 0; i < PAGE_SLOTS.length && start + i < players.size(); i++) {
            Player target = players.get(start + i);
            inventory.setItem(PAGE_SLOTS[i], playerHead(target, "&b" + target.getName(),
                    "&7Level: &f" + target.getLevel(),
                    "&7World: &f" + target.getWorld().getName(),
                    "", "&eClick to send a teleport request"));
        }
        if (players.isEmpty()) {
            inventory.setItem(22, item(Material.BARRIER, "&cNo Other Players Online", "&7There is nobody to request right now."));
        }
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        viewer.openInventory(inventory);
    }

    private void openRequestsMenu(Player viewer, int pageIndex) {
        cleanupTpaRequests();
        List<UUID> requesters = getIncomingRequesters(viewer.getUniqueId());
        int maxPage = Math.max(0, (requesters.size() - 1) / PAGE_SLOTS.length);
        int safePage = Math.max(0, Math.min(pageIndex, maxPage));
        Inventory inventory = createMenu(viewer, Page.REQUESTS, safePage, "&8Teleport Requests &7• &f" + (safePage + 1));
        ((MenuHolder) inventory.getHolder()).setEntries(requesters.stream().map(UUID::toString).toList());

        int start = safePage * PAGE_SLOTS.length;
        Map<UUID, Long> incoming = incomingTpaRequests.get(viewer.getUniqueId());
        for (int i = 0; i < PAGE_SLOTS.length && start + i < requesters.size(); i++) {
            UUID requesterId = requesters.get(start + i);
            Player requester = Bukkit.getPlayer(requesterId);
            Long expiresAt = incoming == null ? null : incoming.get(requesterId);
            if (requester == null || expiresAt == null) continue;
            long secondsLeft = Math.max(0L, (expiresAt - System.currentTimeMillis() + 999L) / 1000L);
            inventory.setItem(PAGE_SLOTS[i], playerHead(requester, "&b" + requester.getName(),
                    "&7Wants to teleport to you.",
                    "&7Expires in: &f" + secondsLeft + "s", "",
                    "&aLeft-click: accept", "&cRight-click: deny"));
        }
        if (requesters.isEmpty()) {
            inventory.setItem(22, item(Material.MAP, "&7No Pending Requests", "&7New teleport requests will appear here."));
        }
        if (safePage > 0) inventory.setItem(47, item(Material.ARROW, "&ePrevious Page"));
        if (safePage < maxPage) inventory.setItem(51, item(Material.ARROW, "&eNext Page"));
        inventory.setItem(49, backButton());
        viewer.openInventory(inventory);
    }

    private void openRulesMenu(Player player) {
        Inventory inventory = createMenu(player, Page.RULES, 0, "&8Server Rules");
        List<String> rules = getConfig().getStringList("rules");
        if (rules.isEmpty()) {
            rules = List.of("Be respectful to other players.", "No cheating or exploiting bugs.", "Keep chat friendly and appropriate.", "Respect builds and other players' items.");
        }
        List<String> lore = new ArrayList<>();
        lore.add("&7Please follow these guidelines:");
        lore.add("");
        for (int i = 0; i < rules.size() && i < 12; i++) {
            lore.add("&f" + (i + 1) + ". &7" + rules.get(i));
        }
        inventory.setItem(22, item(Material.BOOK, "&eCommunity Guidelines", lore.toArray(new String[0])));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openSettingsMenu(Player player) {
        Inventory inventory = createMenu(player, Page.SETTINGS, 0, "&8Personal Settings");
        boolean notifications = receivesNotifications(player);
        inventory.setItem(20, item(notifications ? Material.LIME_DYE : Material.GRAY_DYE,
                "&dServer Notifications",
                "&7Show join and leave messages in chat.", "",
                "&7Current: " + (notifications ? "&aEnabled" : "&cDisabled"),
                "", "&eClick to toggle"));
        boolean scoreboardEnabled = isScoreboardEnabled(player);
        inventory.setItem(24, item(scoreboardEnabled ? Material.LIME_DYE : Material.GRAY_DYE,
                "&bSidebar Scoreboard", "&7Show your balance, playtime and quest progress.", "",
                "&7Current: " + (scoreboardEnabled ? "&aEnabled" : "&cDisabled"), "", "&eClick to toggle"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openAdminMenu(Player player) {
        if (!player.hasPermission("smpcore.admin")) {
            player.sendMessage(color(PREFIX + "You do not have permission to use this menu."));
            openMainMenu(player);
            return;
        }
        Inventory inventory = createMenu(player, Page.ADMIN, 0, "&8SMPCore Admin");
        inventory.setItem(11, item(Material.BEACON, "&cSet Server Spawn", "&7Set spawn to your current location", "", "&eClick to save"));
        inventory.setItem(13, item(Material.NAME_TAG, "&aCreate Warp", "&7Create a warp at your current location", "", "&eClick, then enter a name in chat"));
        inventory.setItem(15, item(Material.FIREWORK_ROCKET, "&6Server Announcement", "&7Send a message to all online players", "", "&eClick, then type your message"));
        inventory.setItem(29, item(Material.CLOCK, "&eReload Configuration", "&7Reload config.yml and menu rules", "", "&eClick to reload"));
        inventory.setItem(31, item(Material.PAPER, "&7Admin Help", "&7Manage spawn, warps and announcements.", "&7All tools are available in this menu."));
        inventory.setItem(33, item(Material.GOLD_INGOT, "&6Economy Manager", "&7View and edit online player balances", "", "&eClick to manage wallets"));
        inventory.setItem(35, item(Material.BUNDLE, "&bCreate Storage Backup", "&7Save all SMPCore data files first", "&7Keep the newest backups automatically", "", "&eClick to create a backup"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    private void openServerInfoMenu(Player player) {
        Inventory inventory = createMenu(player, Page.SERVER, 0, "&8Server Information");
        inventory.setItem(20, item(Material.PLAYER_HEAD, "&bPlayers Online",
                "&7Currently online: &f" + Bukkit.getOnlinePlayers().size(),
                "&7Maximum slots: &f" + Bukkit.getMaxPlayers()));
        inventory.setItem(22, item(Material.GRASS_BLOCK, "&aWorlds",
                "&7Loaded worlds: &f" + Bukkit.getWorlds().size(),
                "&7Current world: &f" + player.getWorld().getName()));
        inventory.setItem(24, item(Material.PAPER, "&eServer Version",
                "&7Minecraft: &f" + Bukkit.getMinecraftVersion(),
                "&7Server: &f" + Bukkit.getName()));
        inventory.setItem(31, item(Material.NETHER_STAR, "&6SMPCore",
                "&7Plugin version: &f" + getDescription().getVersion(),
                "&7Created by: &fREN"));
        inventory.setItem(49, backButton());
        player.openInventory(inventory);
    }

    // ---------------------------------------------------------------------
    // Inventory interactions
    // ---------------------------------------------------------------------

    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder<?> rawHolder)) return;
        @SuppressWarnings("unchecked")
        MenuHolder<Page> holder = (MenuHolder<Page>) rawHolder;

        event.setCancelled(true);
        if (!holder.viewer.equals(player.getUniqueId())) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        switch (holder.page) {
            case MAIN -> handleMainClick(player, slot);
            case PROFILE, RULES, SERVER, STATS, LEADERBOARD -> {
                if (slot == 49) openMainMenu(player);
            }
            case DAILY_REWARD -> {
                if (slot == 49) openMainMenu(player);
                else if (slot == 22) claimDailyReward(player);
            }
            case HOMES -> handleHomesClick(player, holder, slot, event.isRightClick());
            case WARPS -> handleWarpsClick(player, holder, slot, event.isRightClick());
            case KITS -> handleKitsClick(player, holder, slot);
            case SHOP -> handleShopClick(player, holder, slot);
            case SETTINGS -> handleSettingsClick(player, slot);
            case ADMIN -> handleAdminClick(player, slot);
            case PLAYERS -> handlePlayersClick(player, holder, slot);
            case PAY_PLAYERS -> handlePayPlayersClick(player, holder, slot);
            case ECONOMY_ADMIN -> handleAdminEconomyClick(player, holder, slot);
            case ECONOMY_ADMIN_PLAYER -> handleAdminEconomyPlayerClick(player, holder, slot);
            case REQUESTS -> handleRequestsClick(player, holder, slot, event.isRightClick());
            case QUESTS -> handleQuestsClick(player, holder, slot);
            case MARKET -> handleMarketClick(player, holder, slot);
            case MARKET_MINE -> handleMyMarketClick(player, holder, slot);
        }
    }

    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder<?>) {
            event.setCancelled(true);
        }
    }

    private void handleMainClick(Player player, int slot) {
        switch (slot) {
            case 10 -> openProfileMenu(player);
            case 12 -> openHomesMenu(player, 0);
            case 14 -> openWarpsMenu(player, 0);
            case 16 -> teleportToSpawn(player);
            case 20 -> openKitsMenu(player, 0);
            case 24 -> { if (getConfig().getBoolean("shop.enabled", true) && getConfig().getBoolean("economy.enabled", true)) openShopMenu(player, 0); }
            case 26 -> { if (getConfig().getBoolean("economy.enabled", true)) openPayPlayersMenu(player, 0); }
            case 22 -> {
                if (player.hasPermission("smpcore.admin")) openAdminMenu(player);
            }
            case 28 -> openRulesMenu(player);
            case 30 -> openPlayersMenu(player, 0);
            case 32 -> openRequestsMenu(player, 0);
            case 33 -> openQuestsMenu(player, 0);
            case 34 -> openSettingsMenu(player);
            case 37 -> openStatsMenu(player);
            case 39 -> openLeaderboardMenu(player);
            case 41 -> openDailyRewardMenu(player);
            case 42 -> openMarketMenu(player, 0);
            case 43 -> openServerInfoMenu(player);
        }
    }

    private void handleHomesClick(Player player, MenuHolder holder, int slot, boolean rightClick) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) {
            openMainMenu(player);
            return;
        }
        if (slot == 47) {
            openHomesMenu(player, pageIndex - 1);
            return;
        }
        if (slot == 51) {
            openHomesMenu(player, pageIndex + 1);
            return;
        }
        if (slot == 45) {
            int count = getHomeNames(player.getUniqueId()).size();
            if (count >= getMaxHomes(player)) {
                player.sendMessage(color(PREFIX + "You have reached your home limit (&b" + getMaxHomes(player) + "&7)."));
                playClickSound(player);
                return;
            }
            pendingInputs.put(player.getUniqueId(), PendingInput.CREATE_HOME);
            player.closeInventory();
            player.sendMessage(color(PREFIX + "Type a name for your new home. Use 1-16 letters, numbers, _ or -."));
            player.sendMessage(color("&7Your current location will be saved. Type &ccancel &7to stop."));
            return;
        }

        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        String name = holder.entries().get(index);
        if (rightClick) {
            if (!teleportManager.deleteHome(player.getUniqueId(), name)) {
                player.sendMessage(color(PREFIX + "Could not save the deletion. Your home is still available."));
                return;
            }
            player.sendMessage(color(PREFIX + "Home &b" + name + " &7has been deleted."));
            playSuccessSound(player);
            openHomesMenu(player, pageIndex);
            return;
        }
        Location home = getHome(player.getUniqueId(), name);
        if (home == null) {
            player.sendMessage(color(PREFIX + "That home is unavailable because its world is not loaded."));
            openHomesMenu(player, pageIndex);
            return;
        }
        player.closeInventory();
        teleport(player, home, "home " + name);
    }

    private void handleKitsClick(Player player, MenuHolder holder, int slot) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) {
            openMainMenu(player);
            return;
        }
        if (slot == 47) {
            openKitsMenu(player, pageIndex - 1);
            return;
        }
        if (slot == 51) {
            openKitsMenu(player, pageIndex + 1);
            return;
        }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        claimKit(player, holder.entries().get(index));
    }

    private void handleShopClick(Player player, MenuHolder holder, int slot) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) { openMainMenu(player); return; }
        if (slot == 47) { openShopMenu(player, pageIndex - 1); return; }
        if (slot == 51) { openShopMenu(player, pageIndex + 1); return; }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        purchaseShopItem(player, holder.entries().get(index));
    }

    private void purchaseShopItem(Player player, String productKey) {
        if (!getConfig().getBoolean("economy.enabled", true) || !getConfig().getBoolean("shop.enabled", true)) {
            player.sendMessage(color(PREFIX + "The shop is currently disabled."));
            return;
        }
        ConfigurationSection product = getConfig().getConfigurationSection("shop." + productKey);
        if (product == null) return;
        String permission = product.getString("permission", "");
        if (permission != null && !permission.isBlank() && !player.hasPermission(permission)) {
            player.sendMessage(color(PREFIX + "You do not have permission to buy this item."));
            return;
        }
        Material material = Material.matchMaterial(product.getString("material", ""));
        int amount = product.getInt("amount", 1);
        long price = product.getLong("price", -1L);
        if (material == null || !material.isItem() || amount < 1 || amount > 2304 || price < 0L) {
            player.sendMessage(color(PREFIX + "This shop product is configured incorrectly. Please contact an administrator."));
            return;
        }
        List<ItemStack> rewards = new ArrayList<>();
        int remaining = amount;
        while (remaining > 0) {
            int stackAmount = Math.min(remaining, material.getMaxStackSize());
            ItemStack reward = new ItemStack(material, stackAmount);
            String displayName = product.getString("display-name", "");
            if (displayName != null && !displayName.isBlank()) {
                ItemMeta meta = reward.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(color(displayName));
                    reward.setItemMeta(meta);
                }
            }
            rewards.add(reward);
            remaining -= stackAmount;
        }
        if (hasOverflow(rewards, player.getInventory().getStorageContents())) {
            player.sendMessage(color(PREFIX + "Your inventory does not have enough space for this purchase."));
            return;
        }
        long balance = getBalance(player.getUniqueId());
        if (balance < price) {
            player.sendMessage(color(PREFIX + "You need &6" + formatCoins(price - balance) + " &7more to buy this."));
            return;
        }
        ItemStack[] inventoryBefore = cloneContents(player.getInventory().getStorageContents());
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(rewards.toArray(new ItemStack[0]));
        if (!leftovers.isEmpty()) {
            player.getInventory().setStorageContents(inventoryBefore);
            player.sendMessage(color(PREFIX + "Your inventory changed before the purchase completed. No coins were charged."));
            return;
        }
        if (!setBalance(player.getUniqueId(), balance - price)) {
            player.getInventory().setStorageContents(inventoryBefore);
            player.sendMessage(color(PREFIX + "The purchase could not be saved. Your items and balance were restored."));
            return;
        }
        if (storageManager != null) storageManager.audit("SHOP_PURCHASE", player.getUniqueId(), null,
                "product=" + productKey + " material=" + material.name() + " amount=" + amount + " price=" + price);
        player.sendMessage(color(PREFIX + "Purchased &b" + amount + "x " + material.name() + " &7for &6" + formatCoins(price) + "&7."));
        playSuccessSound(player);
        openShopMenu(player, holderPageForShop(player));
    }

    private int holderPageForShop(Player player) {
        if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder<?> holder && holder.page == Page.SHOP) {
            return holder.pageIndex;
        }
        return 0;
    }

    private void handlePayPlayersClick(Player player, MenuHolder holder, int slot) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) { openMainMenu(player); return; }
        if (slot == 47) { openPayPlayersMenu(player, pageIndex - 1); return; }
        if (slot == 51) { openPayPlayersMenu(player, pageIndex + 1); return; }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        UUID targetId = UUID.fromString(holder.entries().get(index));
        Player target = Bukkit.getPlayer(targetId);
        if (target == null) {
            player.sendMessage(color(PREFIX + "That player is no longer online."));
            openPayPlayersMenu(player, pageIndex);
            return;
        }
        pendingPaymentTargets.put(player.getUniqueId(), targetId);
        pendingInputs.put(player.getUniqueId(), PendingInput.PAY_AMOUNT);
        player.closeInventory();
        player.sendMessage(color(PREFIX + "Enter the number of coins to send to &b" + target.getName() + "&7."));
        player.sendMessage(color("&7Maximum transfer: &6" + formatCoins(Math.max(1L, getConfig().getLong("economy.max-payment", 1000000L))) + "&7. Type &ccancel &7to stop."));
    }

    private void handleAdminEconomyClick(Player player, MenuHolder holder, int slot) {
        if (!player.hasPermission("smpcore.admin")) return;
        int pageIndex = holder.pageIndex;
        if (slot == 49) { openAdminMenu(player); return; }
        if (slot == 47) { openAdminEconomyMenu(player, pageIndex - 1); return; }
        if (slot == 51) { openAdminEconomyMenu(player, pageIndex + 1); return; }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        openAdminEconomyPlayerMenu(player, UUID.fromString(holder.entries().get(index)));
    }

    private void handleAdminEconomyPlayerClick(Player admin, MenuHolder holder, int slot) {
        if (!admin.hasPermission("smpcore.admin") || holder.entries().isEmpty()) return;
        if (slot == 49) { openAdminEconomyMenu(admin, 0); return; }
        UUID targetId = UUID.fromString(holder.entries().get(0));
        long balance = getBalance(targetId);
        if (slot == 20) {
            if (!addBalance(targetId, 100L)) {
                admin.sendMessage(color(PREFIX + "Could not add coins. The wallet may be full or storage may be unavailable."));
                return;
            }
            if (storageManager != null) storageManager.audit("ADMIN_DEPOSIT", admin.getUniqueId(), targetId, "amount=100");
            admin.sendMessage(color(PREFIX + "Added &a100 coins&7. New balance: &6" + formatCoins(getBalance(targetId))));
            playSuccessSound(admin);
            openAdminEconomyPlayerMenu(admin, targetId);
        } else if (slot == 22) {
            if (balance < 100L) {
                admin.sendMessage(color(PREFIX + "That player does not have 100 coins to withdraw."));
                return;
            }
            if (!setBalance(targetId, balance - 100L)) {
                admin.sendMessage(color(PREFIX + "Could not save this wallet change. No coins were withdrawn."));
                return;
            }
            if (storageManager != null) storageManager.audit("ADMIN_WITHDRAW", admin.getUniqueId(), targetId, "amount=100");
            admin.sendMessage(color(PREFIX + "Removed &c100 coins&7. New balance: &6" + formatCoins(getBalance(targetId))));
            playSuccessSound(admin);
            openAdminEconomyPlayerMenu(admin, targetId);
        } else if (slot == 24) {
            pendingEconomyTargets.put(admin.getUniqueId(), targetId);
            pendingInputs.put(admin.getUniqueId(), PendingInput.ADMIN_SET_BALANCE);
            admin.closeInventory();
            admin.sendMessage(color(PREFIX + "Enter the new whole-number balance for this player."));
            admin.sendMessage(color("&7Use a value from 0 to " + Long.MAX_VALUE + ". Type &ccancel &7to stop."));
        }
    }

    private void transferCoins(Player sender, Player recipient, long amount) {
        if (!getConfig().getBoolean("economy.enabled", true)) {
            sender.sendMessage(color(PREFIX + "The economy is currently disabled."));
            return;
        }
        if (amount <= 0L) {
            sender.sendMessage(color(PREFIX + "Enter an amount greater than zero."));
            return;
        }
        long maximum = Math.max(1L, getConfig().getLong("economy.max-payment", 1000000L));
        if (amount > maximum) {
            sender.sendMessage(color(PREFIX + "The maximum transfer is &6" + formatCoins(maximum) + "&7."));
            return;
        }
        if (sender.getUniqueId().equals(recipient.getUniqueId())) {
            sender.sendMessage(color(PREFIX + "You cannot pay yourself."));
            return;
        }
        long senderBalance = getBalance(sender.getUniqueId());
        long recipientBalance = getBalance(recipient.getUniqueId());
        if (senderBalance < amount) {
            sender.sendMessage(color(PREFIX + "Insufficient funds. Your balance is &6" + formatCoins(senderBalance) + "&7."));
            return;
        }
        if (recipientBalance > Long.MAX_VALUE - amount) {
            sender.sendMessage(color(PREFIX + "That player's wallet cannot receive this amount."));
            return;
        }
        if (!economyManager.transfer(sender.getUniqueId(), recipient.getUniqueId(), amount)) {
            sender.sendMessage(color(PREFIX + "Payment could not be saved. No coins were transferred."));
            return;
        }
        if (storageManager != null) storageManager.audit("COIN_TRANSFER", sender.getUniqueId(), recipient.getUniqueId(), "amount=" + amount);
        sender.sendMessage(color(PREFIX + "You sent &6" + formatCoins(amount) + " &7to &b" + recipient.getName() + "&7."));
        recipient.sendMessage(color(PREFIX + "You received &6" + formatCoins(amount) + " &7from &b" + sender.getName() + "&7."));
        playSuccessSound(sender);
        playSuccessSound(recipient);
    }

    private void claimKit(Player player, String kitName) {
        if (!getConfig().getBoolean("kits.enabled", true)) {
            player.sendMessage(color(PREFIX + "Kits are currently disabled."));
            return;
        }
        ConfigurationSection kit = getConfig().getConfigurationSection("kits." + kitName);
        if (kit == null) return;
        String permission = kit.getString("permission", "");
        if (permission != null && !permission.isBlank() && !player.hasPermission(permission)) {
            player.sendMessage(color(PREFIX + "You do not have permission to claim this kit."));
            return;
        }
        long now = System.currentTimeMillis();
        long cooldownSeconds = Math.max(0L, kit.getLong("cooldown-seconds", 86400L));
        String cooldownPath = "players." + player.getUniqueId() + ".kit-cooldowns." + kitName;
        long readyAt = cooldownSeconds > 0L ? playerSettings.getLong(cooldownPath, 0L) : 0L;
        if (readyAt > now) {
            player.sendMessage(color(PREFIX + "You can claim this kit in &b" + formatDuration(readyAt - now) + "&7."));
            openKitsMenu(player, 0);
            return;
        }

        List<ItemStack> rewards = parseKitItems(kit.getStringList("items"));
        if (rewards.isEmpty()) {
            player.sendMessage(color(PREFIX + "This kit has no valid items. Please contact an administrator."));
            return;
        }
        if (hasOverflow(rewards, player.getInventory().getStorageContents())) {
            player.sendMessage(color(PREFIX + "Your inventory does not have enough space for this kit."));
            return;
        }

        ItemStack[] inventoryBefore = cloneContents(player.getInventory().getStorageContents());
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(rewards.toArray(new ItemStack[0]));
        if (!leftovers.isEmpty()) {
            player.getInventory().setStorageContents(inventoryBefore);
            player.sendMessage(color(PREFIX + "Your inventory changed before the kit could be delivered. Nothing was claimed."));
            return;
        }
        if (cooldownSeconds > 0L && !updatePlayerSettings(settings ->
                settings.set(cooldownPath, now + cooldownSeconds * 1000L), "kit cooldown")) {
            player.getInventory().setStorageContents(inventoryBefore);
            player.sendMessage(color(PREFIX + "The kit cooldown could not be saved. The kit was not claimed."));
            return;
        }
        if (storageManager != null) storageManager.audit("KIT_CLAIM", player.getUniqueId(), null, "kit=" + kitName);
        player.sendMessage(color(PREFIX + "You claimed the &b" + kitName + " &7kit."));
        playSuccessSound(player);
        openKitsMenu(player, 0);
    }

    private List<ItemStack> parseKitItems(List<String> definitions) {
        List<ItemStack> result = new ArrayList<>();
        for (String definition : definitions) {
            if (definition == null) continue;
            String[] parts = definition.trim().split(":", 2);
            if (parts.length != 2) continue;
            Material material = Material.matchMaterial(parts[0].trim());
            if (material == null || !material.isItem()) continue;
            int amount;
            try {
                amount = Integer.parseInt(parts[1].trim());
            } catch (NumberFormatException ignored) {
                continue;
            }
            if (amount < 1 || amount > 2304) continue;
            while (amount > 0) {
                int stackAmount = Math.min(amount, material.getMaxStackSize());
                result.add(new ItemStack(material, stackAmount));
                amount -= stackAmount;
            }
        }
        return result;
    }

    private boolean hasOverflow(List<ItemStack> rewards, ItemStack[] storageContents) {
        Inventory preview = Bukkit.createInventory(null, 36);
        preview.setContents(storageContents);
        for (ItemStack reward : rewards) {
            if (!preview.addItem(reward.clone()).isEmpty()) return true;
        }
        return false;
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0L, (millis + 999L) / 1000L);
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long remainder = seconds % 60L;
        if (hours > 0) return hours + "h " + minutes + "m";
        if (minutes > 0) return minutes + "m " + remainder + "s";
        return remainder + "s";
    }

    private void handleWarpsClick(Player player, MenuHolder holder, int slot, boolean rightClick) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) {
            openMainMenu(player);
            return;
        }
        if (slot == 47) {
            openWarpsMenu(player, pageIndex - 1);
            return;
        }
        if (slot == 51) {
            openWarpsMenu(player, pageIndex + 1);
            return;
        }

        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        String name = holder.entries().get(index);

        if (rightClick && player.hasPermission("smpcore.admin")) {
            if (!teleportManager.deleteWarp(name)) {
                player.sendMessage(color(PREFIX + "Could not save the deletion. The warp is still available."));
                return;
            }
            player.sendMessage(color(PREFIX + "Warp &b" + name + " &7has been deleted."));
            playSuccessSound(player);
            openWarpsMenu(player, pageIndex);
            return;
        }

        Location location = getWarp(name);
        if (location == null) {
            player.sendMessage(color(PREFIX + "That warp is unavailable because its world is not loaded."));
            openWarpsMenu(player, pageIndex);
            return;
        }
        player.closeInventory();
        teleport(player, location, name);
    }

    private void handlePlayersClick(Player player, MenuHolder holder, int slot) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) {
            openMainMenu(player);
            return;
        }
        if (slot == 47) {
            openPlayersMenu(player, pageIndex - 1);
            return;
        }
        if (slot == 51) {
            openPlayersMenu(player, pageIndex + 1);
            return;
        }

        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        UUID targetId = UUID.fromString(holder.entries().get(index));
        Player target = Bukkit.getPlayer(targetId);
        if (target == null) {
            player.sendMessage(color(PREFIX + "That player is no longer online. The list has been refreshed."));
            openPlayersMenu(player, pageIndex);
            return;
        }
        sendTpaRequest(player, target);
        openPlayersMenu(player, pageIndex);
    }

    private void handleRequestsClick(Player player, MenuHolder holder, int slot, boolean rightClick) {
        int pageIndex = holder.pageIndex;
        if (slot == 49) {
            openMainMenu(player);
            return;
        }
        if (slot == 47) {
            openRequestsMenu(player, pageIndex - 1);
            return;
        }
        if (slot == 51) {
            openRequestsMenu(player, pageIndex + 1);
            return;
        }

        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;

        UUID requesterId = UUID.fromString(holder.entries().get(index));
        Map<UUID, Long> incoming = incomingTpaRequests.get(player.getUniqueId());
        Long expiry = incoming == null ? null : incoming.get(requesterId);
        if (expiry == null || expiry <= System.currentTimeMillis()) {
            removeTpaRequest(requesterId, player.getUniqueId());
            player.sendMessage(color(PREFIX + "That request has expired or is no longer available."));
            openRequestsMenu(player, pageIndex);
            return;
        }

        Player requester = Bukkit.getPlayer(requesterId);
        removeTpaRequest(requesterId, player.getUniqueId());

        if (requester == null) {
            player.sendMessage(color(PREFIX + "That player is no longer online."));
            openRequestsMenu(player, pageIndex);
            return;
        }

        if (rightClick) {
            player.sendMessage(color(PREFIX + "You declined &b" + requester.getName() + "&7's request."));
            requester.sendMessage(color(PREFIX + "&b" + player.getName() + " &7declined your teleport request."));
            playClickSound(player);
            openRequestsMenu(player, pageIndex);
            return;
        }

        player.closeInventory();
        player.sendMessage(color(PREFIX + "You accepted &b" + requester.getName() + "&7's request."));
        requester.sendMessage(color(PREFIX + "Your teleport request was accepted."));
        teleport(requester, player.getLocation(), player.getName());
    }

    private void handleQuestsClick(Player player, MenuHolder holder, int slot) {
        if (slot == 49) { openMainMenu(player); return; }
        if (slot == 47) { openQuestsMenu(player, holder.pageIndex - 1); return; }
        if (slot == 51) { openQuestsMenu(player, holder.pageIndex + 1); return; }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = holder.pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        claimQuest(player, holder.entries().get(index), holder.pageIndex);
    }

    private void handleMarketClick(Player player, MenuHolder holder, int slot) {
        if (slot == 49) { openMainMenu(player); return; }
        if (slot == 45) { startMarketListing(player); return; }
        if (slot == 53) { openMyMarketMenu(player, 0); return; }
        if (slot == 47) { openMarketMenu(player, holder.pageIndex - 1); return; }
        if (slot == 51) { openMarketMenu(player, holder.pageIndex + 1); return; }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = holder.pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        purchaseMarketListing(player, holder.entries().get(index), holder.pageIndex);
    }

    private void handleMyMarketClick(Player player, MenuHolder holder, int slot) {
        if (slot == 49) { openMarketMenu(player, 0); return; }
        if (slot == 47) { openMyMarketMenu(player, holder.pageIndex - 1); return; }
        if (slot == 51) { openMyMarketMenu(player, holder.pageIndex + 1); return; }
        int indexInPage = getPageIndexForSlot(slot);
        if (indexInPage < 0) return;
        int index = holder.pageIndex * PAGE_SLOTS.length + indexInPage;
        if (index >= holder.entries().size()) return;
        cancelMarketListing(player, holder.entries().get(index), holder.pageIndex);
    }

    private void handleSettingsClick(Player player, int slot) {
        if (slot == 49) {
            openMainMenu(player);
        } else if (slot == 20) {
            String path = "players." + player.getUniqueId() + ".notifications";
            boolean previous = receivesNotifications(player);
            if (!updatePlayerSettings(settings -> settings.set(path, !previous), "notification setting")) {
                player.sendMessage(color(PREFIX + "Could not save that setting. Your previous preference was kept."));
                return;
            }
            playClickSound(player);
            openSettingsMenu(player);
        } else if (slot == 24) {
            String path = "players." + player.getUniqueId() + ".scoreboard";
            boolean enabled = !isScoreboardEnabled(player);
            if (!updatePlayerSettings(settings -> settings.set(path, enabled), "scoreboard setting")) {
                player.sendMessage(color(PREFIX + "Could not save that setting. Your previous preference was kept."));
                return;
            }
            if (enabled) updateScoreboard(player); else removeScoreboard(player);
            playClickSound(player);
            openSettingsMenu(player);
        }
    }

    private void handleAdminClick(Player player, int slot) {
        if (!player.hasPermission("smpcore.admin")) return;
        if (slot == 49) {
            openMainMenu(player);
        } else if (slot == 11) {
            getConfig().set("spawn", player.getLocation());
            saveConfig();
            player.sendMessage(color(PREFIX + "Server spawn has been updated."));
            playSuccessSound(player);
            openAdminMenu(player);
        } else if (slot == 13) {
            pendingInputs.put(player.getUniqueId(), PendingInput.CREATE_WARP);
            pendingWarpLocations.put(player.getUniqueId(), player.getLocation().clone());
            player.closeInventory();
            player.sendMessage(color(PREFIX + "Type a warp name in chat. Use 1-16 letters, numbers, _ or -."));
            player.sendMessage(color("&7The warp will use the location where you clicked Create Warp."));
            player.sendMessage(color("&7Type &ccancel &7to stop."));
        } else if (slot == 15) {
            pendingInputs.put(player.getUniqueId(), PendingInput.BROADCAST);
            pendingWarpLocations.remove(player.getUniqueId());
            player.closeInventory();
            player.sendMessage(color(PREFIX + "Type the announcement you want to send to everyone."));
            player.sendMessage(color("&7Maximum length: " + MAX_BROADCAST_LENGTH + " characters. Use & for colors."));
            player.sendMessage(color("&7Type &ccancel &7to stop."));
        } else if (slot == 33) {
            openAdminEconomyMenu(player, 0);
        } else if (slot == 29) {
            reloadConfig();
            configManager.applyDefaultsAndValidate();
            questManager = new QuestManager(getConfig(), playerSettings, economyManager,
                    () -> playerSettingsDirty = true);
            scheduleScoreboardUpdates();
            scheduleAutomaticBackups();
            updateAllScoreboards();
            player.sendMessage(color(PREFIX + "Configuration reloaded. Active scoreboards and scheduled backups refreshed."));
            playSuccessSound(player);
            openAdminMenu(player);
        } else if (slot == 35) {
            createStorageBackup(player, false);
            openAdminMenu(player);
        }
    }

    private int getPageIndexForSlot(int slot) {
        for (int i = 0; i < PAGE_SLOTS.length; i++) {
            if (PAGE_SLOTS[i] == slot) return i;
        }
        return -1;
    }

    // ---------------------------------------------------------------------
    // Teleport requests
    // ---------------------------------------------------------------------

    private void sendTpaRequest(Player requester, Player target) {
        cleanupTpaRequests();
        if (!getConfig().getBoolean("tpa.enabled", true)) {
            requester.sendMessage(color(PREFIX + "Teleport requests are currently disabled."));
            return;
        }
        if (requester.getUniqueId().equals(target.getUniqueId())) return;
        if (!target.isOnline()) {
            requester.sendMessage(color(PREFIX + "That player is no longer online."));
            return;
        }

        long now = System.currentTimeMillis();
        long cooldownUntil = tpaCooldowns.getOrDefault(requester.getUniqueId(), 0L);
        if (now < cooldownUntil) {
            long remaining = Math.max(1L, (cooldownUntil - now + 999L) / 1000L);
            requester.sendMessage(color(PREFIX + "Please wait &b" + remaining + "s &7before sending another request."));
            return;
        }

        UUID existingTarget = outgoingTpaRequests.get(requester.getUniqueId());
        if (existingTarget != null) {
            requester.sendMessage(color(PREFIX + "You already have a pending teleport request."));
            return;
        }

        LinkedHashMap<UUID, Long> requests = incomingTpaRequests.computeIfAbsent(target.getUniqueId(), key -> new LinkedHashMap<>());
        if (requests.containsKey(requester.getUniqueId())) {
            requester.sendMessage(color(PREFIX + "You already sent a request to that player."));
            return;
        }
        int maxPending = Math.max(1, getConfig().getInt("tpa.max-pending-per-player", 10));
        if (requests.size() >= maxPending) {
            requester.sendMessage(color(PREFIX + "That player has too many pending requests right now."));
            return;
        }

        int timeoutSeconds = Math.max(10, getConfig().getInt("tpa.timeout-seconds", 60));
        long expiresAt = now + timeoutSeconds * 1000L;
        requests.put(requester.getUniqueId(), expiresAt);
        outgoingTpaRequests.put(requester.getUniqueId(), target.getUniqueId());
        int cooldownSeconds = Math.max(0, getConfig().getInt("tpa.cooldown-seconds", 10));
        tpaCooldowns.put(requester.getUniqueId(), now + cooldownSeconds * 1000L);

        requester.sendMessage(color(PREFIX + "Teleport request sent to &b" + target.getName() + "&7."));
        target.sendMessage(color(PREFIX + "&b" + requester.getName() + " &7wants to teleport to you."));
        target.sendMessage(color("&7Open &f/menu &7→ &fTeleport Requests &7to accept or decline."));
        playClickSound(requester);
    }

    private void cleanupTpaRequests() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, LinkedHashMap<UUID, Long>>> outer = incomingTpaRequests.entrySet().iterator();
        while (outer.hasNext()) {
            Map.Entry<UUID, LinkedHashMap<UUID, Long>> entry = outer.next();
            UUID targetId = entry.getKey();
            Iterator<Map.Entry<UUID, Long>> inner = entry.getValue().entrySet().iterator();
            while (inner.hasNext()) {
                Map.Entry<UUID, Long> request = inner.next();
                UUID requesterId = request.getKey();
                if (request.getValue() <= now || Bukkit.getPlayer(requesterId) == null || Bukkit.getPlayer(targetId) == null) {
                    inner.remove();
                    outgoingTpaRequests.remove(requesterId, targetId);
                    Player requester = Bukkit.getPlayer(requesterId);
                    if (requester != null && request.getValue() <= now) {
                        requester.sendMessage(color(PREFIX + "Your teleport request expired."));
                    }
                }
            }
            if (entry.getValue().isEmpty()) outer.remove();
        }
        tpaCooldowns.entrySet().removeIf(entry -> entry.getValue() <= now);
    }

    private List<UUID> getIncomingRequesters(UUID targetId) {
        Map<UUID, Long> requests = incomingTpaRequests.get(targetId);
        if (requests == null) return new ArrayList<>();
        List<UUID> requesters = new ArrayList<>(requests.keySet());
        requesters.removeIf(id -> Bukkit.getPlayer(id) == null);
        requesters.sort(Comparator.comparing(id -> {
            Player player = Bukkit.getPlayer(id);
            return player == null ? "" : player.getName().toLowerCase(Locale.ROOT);
        }));
        return requesters;
    }

    private int getIncomingRequestCount(UUID targetId) {
        Map<UUID, Long> requests = incomingTpaRequests.get(targetId);
        return requests == null ? 0 : (int) requests.values().stream().filter(expiry -> expiry > System.currentTimeMillis()).count();
    }

    private void removeTpaRequest(UUID requesterId, UUID targetId) {
        Map<UUID, Long> requests = incomingTpaRequests.get(targetId);
        if (requests != null) {
            requests.remove(requesterId);
            if (requests.isEmpty()) incomingTpaRequests.remove(targetId);
        }
        outgoingTpaRequests.remove(requesterId, targetId);
    }

    // ---------------------------------------------------------------------
    // Chat input for GUI actions (Paper's modern chat event)
    // ---------------------------------------------------------------------

    public void onChatInput(AsyncChatEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        PendingInput pending = pendingInputs.get(playerId);
        if (pending == null) return;

        event.setCancelled(true);
        if (!processingInputs.add(playerId)) return;
        String input = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        Bukkit.getScheduler().runTask(this, () -> {
            try {
                handlePendingInput(playerId, pending, input);
            } finally {
                processingInputs.remove(playerId);
            }
        });
    }

    private void handlePendingInput(UUID playerId, PendingInput expectedPending, String input) {
        PendingInput currentPending = pendingInputs.get(playerId);
        Player player = Bukkit.getPlayer(playerId);
        if (player == null || currentPending != expectedPending) return;

        if (input.equalsIgnoreCase("cancel")) {
            UUID economyTargetId = expectedPending == PendingInput.ADMIN_SET_BALANCE ? pendingEconomyTargets.get(playerId) : null;
            clearPendingInput(playerId);
            player.sendMessage(color(PREFIX + "Action cancelled."));
            if (expectedPending == PendingInput.CREATE_HOME) openHomesMenu(player, 0);
            else if (expectedPending == PendingInput.PAY_AMOUNT) openPayPlayersMenu(player, 0);
            else if (expectedPending == PendingInput.ADMIN_SET_BALANCE && economyTargetId != null && player.hasPermission("smpcore.admin")) {
                openAdminEconomyPlayerMenu(player, economyTargetId);
            } else if (expectedPending == PendingInput.MARKET_PRICE) {
                openMarketMenu(player, 0);
            } else openAdminMenu(player);
            return;
        }

        if (currentPending == PendingInput.CREATE_HOME) {
            if (!SAFE_NAME.matcher(input).matches()) {
                player.sendMessage(color(PREFIX + "Invalid home name. Use 1-16 letters, numbers, _ or -. Try again, or type cancel."));
                return;
            }
            if (getHomeNames(playerId).size() >= getMaxHomes(player)) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "You have reached your home limit (&b" + getMaxHomes(player) + "&7)."));
                openHomesMenu(player, 0);
                return;
            }
            String homeName = input.toLowerCase(Locale.ROOT);
            if (homes.contains("homes." + playerId + "." + homeName + ".world")) {
                player.sendMessage(color(PREFIX + "A home with that name already exists. Enter another name, or type cancel."));
                return;
            }
            if (!teleportManager.createHome(playerId, homeName, player.getLocation())) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "Could not save that home. No home was created."));
                openHomesMenu(player, 0);
                return;
            }
            clearPendingInput(playerId);
            player.sendMessage(color(PREFIX + "Home &b" + homeName + " &7has been saved."));
            playSuccessSound(player);
            openHomesMenu(player, 0);
            return;
        }

        if (currentPending == PendingInput.CREATE_WARP) {
            if (!player.hasPermission("smpcore.admin")) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "You no longer have permission to create warps."));
                return;
            }
            if (!SAFE_NAME.matcher(input).matches()) {
                player.sendMessage(color(PREFIX + "Invalid name. Use 1-16 letters, numbers, _ or -. Try again, or type cancel."));
                return;
            }
            String warpName = input.toLowerCase(Locale.ROOT);
            if (warps.contains("warps." + warpName)) {
                player.sendMessage(color(PREFIX + "A warp with that name already exists. Enter another name, or type cancel."));
                return;
            }
            Location creationLocation = pendingWarpLocations.get(playerId);
            if (creationLocation == null || creationLocation.getWorld() == null) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "Could not find the saved creation location. Please try again."));
                return;
            }
            if (!teleportManager.createWarp(warpName, creationLocation)) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "Could not save that warp. No warp was created."));
                openAdminMenu(player);
                return;
            }
            clearPendingInput(playerId);
            player.sendMessage(color(PREFIX + "Warp &b" + warpName + " &7created at the selected location."));
            playSuccessSound(player);
            openAdminMenu(player);
            return;
        }

        if (currentPending == PendingInput.BROADCAST) {
            String message = input.replace('\n', ' ').replace('\r', ' ').trim();
            if (message.isEmpty()) {
                player.sendMessage(color(PREFIX + "Announcement cannot be empty. Try again, or type cancel."));
                return;
            }
            if (message.length() > MAX_BROADCAST_LENGTH) {
                player.sendMessage(color(PREFIX + "Announcement is too long. Maximum " + MAX_BROADCAST_LENGTH + " characters."));
                return;
            }
            if (!player.hasPermission("smpcore.admin")) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "You no longer have permission to send announcements."));
                return;
            }
            clearPendingInput(playerId);
            Bukkit.broadcastMessage(color("&8[&6Announcement&8] &f" + message));
            playSuccessSound(player);
            openAdminMenu(player);
            return;
        }

        if (currentPending == PendingInput.PAY_AMOUNT) {
            long amount;
            try { amount = Long.parseLong(input); }
            catch (NumberFormatException exception) {
                player.sendMessage(color(PREFIX + "Invalid amount. Enter a whole number, or type cancel."));
                return;
            }
            UUID targetId = pendingPaymentTargets.get(playerId);
            Player recipient = targetId == null ? null : Bukkit.getPlayer(targetId);
            clearPendingInput(playerId);
            if (recipient == null) {
                player.sendMessage(color(PREFIX + "The selected player is no longer online. Payment cancelled."));
                openMainMenu(player);
                return;
            }
            transferCoins(player, recipient, amount);
            openMainMenu(player);
            return;
        }

        if (currentPending == PendingInput.ADMIN_SET_BALANCE) {
            if (!player.hasPermission("smpcore.admin")) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "You no longer have permission to manage balances."));
                return;
            }
            long amount;
            try { amount = Long.parseLong(input); }
            catch (NumberFormatException exception) {
                player.sendMessage(color(PREFIX + "Invalid balance. Enter a whole number, or type cancel."));
                return;
            }
            if (amount < 0L) {
                player.sendMessage(color(PREFIX + "Balance cannot be negative. Enter 0 or more."));
                return;
            }
            UUID targetId = pendingEconomyTargets.get(playerId);
            if (targetId == null) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "Could not find the selected wallet. Please try again."));
                openAdminEconomyMenu(player, 0);
                return;
            }
            if (!setBalance(targetId, amount)) {
                player.sendMessage(color(PREFIX + "Could not save that wallet. The previous balance has been kept."));
                return;
            }
            if (storageManager != null) storageManager.audit("ADMIN_SET_BALANCE", playerId, targetId, "amount=" + amount);
            clearPendingInput(playerId);
            player.sendMessage(color(PREFIX + "Wallet balance set to &6" + formatCoins(amount) + "&7."));
            playSuccessSound(player);
            openAdminEconomyPlayerMenu(player, targetId);
            return;
        }

        if (currentPending == PendingInput.MARKET_PRICE) {
            long price;
            try { price = Long.parseLong(input); }
            catch (NumberFormatException exception) {
                player.sendMessage(color(PREFIX + "Invalid price. Enter a whole number, or type cancel."));
                return;
            }
            long maximum = Math.max(1L, getConfig().getLong("market.max-price", 1000000000L));
            ItemStack reserved = pendingMarketItems.get(playerId);
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (price <= 0L || price > maximum) {
                player.sendMessage(color(PREFIX + "Price must be between 1 and " + formatCoins(maximum) + ". Try again, or type cancel."));
                return;
            }
            if (reserved == null || hand == null || hand.getType().isAir()
                    || !isMarketMaterialAllowed(reserved.getType())
                    || hand.getAmount() != reserved.getAmount() || !hand.isSimilar(reserved)) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "Your main-hand item changed. Listing cancelled to protect your items."));
                openMarketMenu(player, 0);
                return;
            }
            int maxListings = Math.max(1, getConfig().getInt("market.max-listings-per-player", 5));
            if (getMarketListingIds(true, playerId).size() >= maxListings) {
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "You have reached your listing limit."));
                openMarketMenu(player, 0);
                return;
            }
            String listingId = UUID.randomUUID().toString();
            String listingPath = "listings." + listingId;
            market.set(listingPath + ".seller", playerId.toString());
            market.set(listingPath + ".seller-name", player.getName());
            market.set(listingPath + ".price", price);
            market.set(listingPath + ".created", System.currentTimeMillis());
            market.set(listingPath + ".item", reserved.clone());
            player.getInventory().setItemInMainHand(null);
            if (!saveYaml(market, marketFile)) {
                market.set(listingPath, null);
                player.getInventory().setItemInMainHand(reserved.clone());
                clearPendingInput(playerId);
                player.sendMessage(color(PREFIX + "Could not save the market listing. Your item has been returned."));
                openMarketMenu(player, 0);
                return;
            }
            clearPendingInput(playerId);
            if (storageManager != null) storageManager.audit("MARKET_LIST", playerId, null, "listing=" + listingId + " price=" + price + " item=" + reserved.getType().name() + " amount=" + reserved.getAmount());
            player.sendMessage(color(PREFIX + "Listed &b" + reserved.getAmount() + "x " + reserved.getType().name() + " &7for &6" + formatCoins(price) + "&7."));
            playSuccessSound(player);
            openMarketMenu(player, 0);
        }
    }

    private void clearPendingInput(UUID playerId) {
        pendingInputs.remove(playerId);
        pendingWarpLocations.remove(playerId);
        pendingPaymentTargets.remove(playerId);
        pendingEconomyTargets.remove(playerId);
        pendingMarketItems.remove(playerId);
    }

    // ---------------------------------------------------------------------
    // Player events and settings
    // ---------------------------------------------------------------------

    public void onQuestBlockBreak(BlockBreakEvent event) {
        if (event.getPlayer().getGameMode() != org.bukkit.GameMode.SURVIVAL
                && event.getPlayer().getGameMode() != org.bukkit.GameMode.ADVENTURE) return;
        incrementQuestProgress(event.getPlayer().getUniqueId(), "BLOCKS_BROKEN", 1L);
    }

    public void onQuestBlockPlace(BlockPlaceEvent event) {
        if (event.getPlayer().getGameMode() != org.bukkit.GameMode.SURVIVAL
                && event.getPlayer().getGameMode() != org.bukkit.GameMode.ADVENTURE) return;
        incrementQuestProgress(event.getPlayer().getUniqueId(), "BLOCKS_PLACED", 1L);
    }

    public void onMobReward(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player) return;
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;
        incrementStat(killer.getUniqueId(), "mob-kills", 1L);
        if (!getConfig().getBoolean("economy.enabled", true)) return;
        long reward = getConfig().getLong("economy.mob-rewards." + event.getEntity().getType().name(), 0L);
        if (reward <= 0L || !addBalanceDeferred(killer.getUniqueId(), reward)) return;
        if (getConfig().getBoolean("economy.reward-message", true)) {
            killer.sendMessage(color(PREFIX + "Mob reward: &6+" + formatCoins(reward) + "&7. Balance: &6" + formatCoins(getBalance(killer.getUniqueId()))));
        }
    }

    public void onPlayerDeath(PlayerDeathEvent event) {
        if (getConfig().getBoolean("stats.enabled", true)) {
            incrementStat(event.getEntity().getUniqueId(), "deaths", 1L);
        }
        Player killer = event.getEntity().getKiller();
        if (killer != null && !killer.getUniqueId().equals(event.getEntity().getUniqueId())) {
            if (getConfig().getBoolean("stats.enabled", true)) {
                incrementStat(killer.getUniqueId(), "player-kills", 1L);
            }
        }
    }

    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        onlinePlaytimeFlush.put(player.getUniqueId(), System.currentTimeMillis());
        playerManager.rememberName(player.getUniqueId(), player.getName());
        Bukkit.getScheduler().runTask(this, () -> updateScoreboard(player));
        if (!getConfig().getBoolean("broadcasts.join-leave", true)) return;
        event.setJoinMessage(null);
        String message = color("&8[&a+&8] &f" + player.getName() + " &7joined the SMP.");
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (receivesNotifications(online)) online.sendMessage(message);
        }
    }

    public void onQuit(PlayerQuitEvent event) {
        UUID quittingId = event.getPlayer().getUniqueId();
        flushPlayerSession(quittingId);
        clearPendingInput(quittingId);
        processingInputs.remove(quittingId);
        removeAllTpaForPlayer(quittingId);
        removeScoreboard(event.getPlayer());
        if (!getConfig().getBoolean("broadcasts.join-leave", true)) return;
        event.setQuitMessage(null);
        String message = color("&8[&c-&8] &f" + event.getPlayer().getName() + " &7left the SMP.");
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.getUniqueId().equals(event.getPlayer().getUniqueId()) && receivesNotifications(online)) {
                online.sendMessage(message);
            }
        }
    }

    private void removeAllTpaForPlayer(UUID playerId) {
        UUID targetId = outgoingTpaRequests.remove(playerId);
        if (targetId != null) removeTpaRequest(playerId, targetId);

        Map<UUID, Long> requests = incomingTpaRequests.remove(playerId);
        if (requests != null) {
            for (UUID requesterId : requests.keySet()) {
                outgoingTpaRequests.remove(requesterId, playerId);
                Player requester = Bukkit.getPlayer(requesterId);
                if (requester != null) requester.sendMessage(color(PREFIX + "Your teleport request was removed because the target left."));
            }
        }
    }

    private boolean isScoreboardEnabled(Player player) {
        return getConfig().getBoolean("scoreboard.enabled", true)
                && playerManager.scoreboardEnabled(player.getUniqueId());
    }

    private void updateAllScoreboards() {
        if (!getConfig().getBoolean("scoreboard.enabled", true)) {
            for (Player player : Bukkit.getOnlinePlayers()) removeScoreboard(player);
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isScoreboardEnabled(player)) updateScoreboard(player);
            else removeScoreboard(player);
        }
    }

    private void updateScoreboard(Player player) {
        if (!player.isOnline() || !isScoreboardEnabled(player)) return;
        Scoreboard board = playerScoreboards.get(player.getUniqueId());
        if (board != null && player.getScoreboard() != board) {
            // Another plugin has taken ownership of this player's scoreboard; do not fight it.
            return;
        }
        Objective objective;
        if (board == null) {
            ScoreboardManager manager = Bukkit.getScoreboardManager();
            if (manager == null) return;
            // Do not replace a scoreboard already managed by another plugin.
            // If that plugin later releases the player back to the main board,
            // the next scheduled update can safely initialize SMPCore's board.
            if (player.getScoreboard() != manager.getMainScoreboard()) return;
            board = manager.getNewScoreboard();
            String configuredTitle = getConfig().getString("scoreboard.title", "&b&lSMPCore");
            if (configuredTitle == null) configuredTitle = "&b&lSMPCore";
            if (configuredTitle.length() > 100) configuredTitle = configuredTitle.substring(0, 100);
            Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(configuredTitle);
            objective = board.registerNewObjective("smpcore", Criteria.DUMMY, title);
            objective.setDisplaySlot(DisplaySlot.SIDEBAR);
            playerScoreboards.put(player.getUniqueId(), board);
            player.setScoreboard(board);
        } else {
            objective = board.getObjective("smpcore");
            if (objective == null) {
                Component title = Component.text("SMPCore", NamedTextColor.AQUA);
                objective = board.registerNewObjective("smpcore", Criteria.DUMMY, title);
                objective.setDisplaySlot(DisplaySlot.SIDEBAR);
            }
        }
        String configuredTitle = getConfig().getString("scoreboard.title", "&b&lSMPCore");
        if (configuredTitle == null) configuredTitle = "&b&lSMPCore";
        if (configuredTitle.length() > 100) configuredTitle = configuredTitle.substring(0, 100);
        objective.displayName(LegacyComponentSerializer.legacyAmpersand().deserialize(configuredTitle));
        for (String old : scoreboardEntries.getOrDefault(player.getUniqueId(), List.of())) board.resetScores(old);
        long questsReady = countReadyQuests(player.getUniqueId());
        List<String> lines = List.of(
                "&8----------------",
                "&b" + player.getName(),
                "&7Coins: &6" + formatCoins(getBalance(player.getUniqueId())),
                "&7Playtime: &f" + formatPlaytime(getStat(player.getUniqueId(), "playtime-seconds")),
                "&7Mob Kills: &f" + getStat(player.getUniqueId(), "mob-kills"),
                "&7Deaths: &f" + getStat(player.getUniqueId(), "deaths"),
                "&7Quests Ready: &a" + questsReady,
                "&7Online: &f" + Bukkit.getOnlinePlayers().size(),
                "&8Enjoy your stay!"
        );
        List<String> entries = new ArrayList<>();
        int score = lines.size();
        ChatColor[] unique = ChatColor.values();
        for (int i = 0; i < lines.size(); i++) {
            String entry = unique[i].toString() + ChatColor.RESET + color(lines.get(i));
            entries.add(entry);
            objective.getScore(entry).setScore(score--);
        }
        scoreboardEntries.put(player.getUniqueId(), entries);
        if (player.getScoreboard() != board) player.setScoreboard(board);
    }

    private long countReadyQuests(UUID playerId) {
        return questManager.countReady(playerId);
    }

    private void removeScoreboard(Player player) {
        UUID id = player.getUniqueId();
        Scoreboard ownedBoard = playerScoreboards.remove(id);
        scoreboardEntries.remove(id);
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager != null && player.isOnline() && ownedBoard != null && player.getScoreboard() == ownedBoard) {
            player.setScoreboard(manager.getMainScoreboard());
        }
    }

    private long getBalance(UUID playerId) {
        return economyManager.getBalance(playerId);
    }

    private boolean setBalance(UUID playerId, long amount) {
        return economyManager.setBalance(playerId, amount);
    }

    private boolean addBalance(UUID playerId, long amount) {
        return economyManager.addBalance(playerId, amount);
    }

    private boolean updatePlayerSettings(Consumer<YamlConfiguration> mutation, String operation) {
        return economyManager.updatePlayerSettings(mutation, operation);
    }

    private boolean addBalanceDeferred(UUID playerId, long amount) {
        return economyManager.addBalanceDeferred(playerId, amount);
    }

    private void restorePlayerSettingsSnapshot(String snapshot, String operation) {
        economyManager.restoreSnapshot(snapshot, operation);
    }

    private ItemStack[] cloneContents(ItemStack[] contents) {
        ItemStack[] copy = new ItemStack[contents.length];
        for (int i = 0; i < contents.length; i++) copy[i] = contents[i] == null ? null : contents[i].clone();
        return copy;
    }

    private String formatCoins(long amount) {
        String symbol = getConfig().getString("economy.currency-symbol", "$");
        if (symbol == null) symbol = "$";
        return symbol + String.format(Locale.US, "%,d", Math.max(0L, amount));
    }

    private boolean receivesNotifications(Player player) {
        return playerManager.receivesNotifications(player.getUniqueId());
    }

    // ---------------------------------------------------------------------
    // Locations and persistence
    // ---------------------------------------------------------------------

    private int getMaxHomes(Player player) {
        int limit = Math.max(1, getConfig().getInt("homes.default-limit", 3));
        for (Map<?, ?> rule : getConfig().getMapList("homes.permission-limits")) {
            Object permissionValue = rule.get("permission");
            Object limitValue = rule.get("limit");
            if (permissionValue == null || !(limitValue instanceof Number number)) continue;
            String permission = String.valueOf(permissionValue).trim();
            int candidate = Math.max(1, number.intValue());
            if (!permission.isEmpty() && player.hasPermission(permission)) limit = Math.max(limit, candidate);
        }
        return limit;
    }

    private List<String> getHomeNames(UUID playerId) {
        return teleportManager.getHomeNames(playerId);
    }

    private Location getHome(UUID playerId, String name) {
        return teleportManager.getHome(playerId, name);
    }

    private List<String> getWarpNames() {
        return teleportManager.getWarpNames();
    }

    private Location getWarp(String name) {
        return teleportManager.getWarp(name);
    }

    private void teleportToSpawn(Player player) {
        Location spawn = getConfig().getLocation("spawn");
        if (spawn == null || spawn.getWorld() == null) spawn = player.getWorld().getSpawnLocation();
        player.closeInventory();
        teleport(player, spawn, "spawn");
    }

    private void teleport(Player player, Location destination, String destinationName) {
        TeleportManager.TeleportResult result = teleportManager.teleport(player, destination);
        switch (result) {
            case SUCCESS -> {
                player.sendMessage(color(PREFIX + "Teleported to &b" + destinationName + "&7."));
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1.2f);
            }
            case OUTSIDE_BORDER -> player.sendMessage(color(PREFIX + "That destination is outside the world's border."));
            case CANCELLED, ERROR -> player.sendMessage(color(PREFIX + "Teleport failed. Please try again."));
            case UNAVAILABLE -> player.sendMessage(color(PREFIX + "That destination is not available."));
        }
    }

    // ---------------------------------------------------------------------
    // Item and sound helpers
    // ---------------------------------------------------------------------

    private ItemStack playerHead(Player player, String name, String... lore) {
        ItemStack stack = new ItemStack(Material.PLAYER_HEAD);
        if (stack.getItemMeta() instanceof SkullMeta meta) {
            meta.setOwningPlayer(player);
            meta.setDisplayName(color(name));
            meta.setLore(colorList(lore));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack enchantedItem(Material material, String name, String... lore) {
        ItemStack stack = item(material, name, lore);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            meta.setLore(colorList(lore));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private List<String> colorList(String... lines) {
        List<String> result = new ArrayList<>();
        for (String line : lines) result.add(color(line));
        return result;
    }

    private ItemStack backButton() {
        return item(Material.ARROW, "&cBack to Main Menu", "&7Return to the main interface");
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void playOpenSound(Player player) {
        if (getConfig().getBoolean("menu.sounds", true)) {
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_CHEST_OPEN, 0.45f, 1.25f);
        }
    }

    private void playClickSound(Player player) {
        if (getConfig().getBoolean("menu.sounds", true)) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.45f, 1.2f);
        }
    }

    private void playSuccessSound(Player player) {
        if (getConfig().getBoolean("menu.sounds", true)) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.4f);
        }
    }
}
