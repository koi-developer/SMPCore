package me.ren.smpcore.player;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

/** Centralizes player profile, preference, and statistic access over the existing players.yml schema. */
public final class PlayerManager {
    private static final Pattern SAFE_PATH = Pattern.compile("[A-Za-z0-9_-]{1,64}(\\.[A-Za-z0-9_-]{1,64}){0,7}");

    private final YamlConfiguration data;
    private final Runnable dirtyMarker;

    public PlayerManager(YamlConfiguration data, Runnable dirtyMarker) {
        if (data == null) throw new IllegalArgumentException("Player data must not be null.");
        this.data = data;
        this.dirtyMarker = dirtyMarker == null ? () -> { } : dirtyMarker;
    }

    public List<UUID> getStoredPlayerIds() {
        ConfigurationSection root = data.getConfigurationSection("players");
        if (root == null) return List.of();
        List<UUID> ids = new ArrayList<>();
        for (String key : root.getKeys(false)) {
            try {
                ids.add(UUID.fromString(key));
            } catch (IllegalArgumentException ignored) {
                // Ignore malformed legacy/player keys rather than breaking the menu.
            }
        }
        return List.copyOf(ids);
    }

    /** Reads a non-negative numeric value using a validated path relative to players.<uuid>. */
    public long getPlayerValue(UUID playerId, String relativePath) {
        if (playerId == null || relativePath == null || !SAFE_PATH.matcher(relativePath).matches()) return 0L;
        return Math.max(0L, data.getLong("players." + playerId + "." + relativePath, 0L));
    }

    public long getStat(UUID playerId, String statKey) {
        return getPlayerValue(playerId, "stats." + statKey);
    }

    public void incrementStat(UUID playerId, String statKey, long amount, boolean trackingEnabled) {
        if (!trackingEnabled || playerId == null || statKey == null
                || !SAFE_PATH.matcher(statKey).matches() || statKey.contains(".") || amount <= 0L) return;
        String path = "players." + playerId + ".stats." + statKey;
        long current = Math.max(0L, data.getLong(path, 0L));
        if (current > Long.MAX_VALUE - amount) return;
        data.set(path, current + amount);
        dirtyMarker.run();
    }

    public String getPlayerName(UUID playerId, String fallback) {
        if (playerId == null) return fallback;
        return data.getString("players." + playerId + ".name", fallback);
    }

    public void rememberName(UUID playerId, String name) {
        if (playerId == null || name == null || name.isBlank()) return;
        String path = "players." + playerId + ".name";
        if (name.equals(data.getString(path))) return;
        data.set(path, name);
        dirtyMarker.run();
    }

    public boolean receivesNotifications(UUID playerId) {
        return playerId != null && data.getBoolean("players." + playerId + ".notifications", true);
    }

    public boolean scoreboardEnabled(UUID playerId) {
        return playerId != null && data.getBoolean("players." + playerId + ".scoreboard", true);
    }

    public String formatPlaytime(long seconds) {
        long safe = Math.max(0L, seconds);
        long days = safe / 86400L;
        long hours = (safe % 86400L) / 3600L;
        long minutes = (safe % 3600L) / 60L;
        if (days > 0) return days + "d " + hours + "h";
        if (hours > 0) return hours + "h " + minutes + "m";
        return minutes + "m";
    }
}
