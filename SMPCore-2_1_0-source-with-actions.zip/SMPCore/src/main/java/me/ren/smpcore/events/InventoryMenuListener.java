package me.ren.smpcore.events;

import me.ren.smpcore.SMPCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.Objects;

/** Routes inventory interactions to SMPCore's menu workflow. */
public final class InventoryMenuListener implements Listener {
    private final SMPCore plugin;

    public InventoryMenuListener(SMPCore plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        plugin.onInventoryClick(event);
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        plugin.onInventoryDrag(event);
    }
}
