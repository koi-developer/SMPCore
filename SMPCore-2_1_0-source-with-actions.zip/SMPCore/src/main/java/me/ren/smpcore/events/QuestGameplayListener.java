package me.ren.smpcore.events;

import me.ren.smpcore.SMPCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.Objects;

/** Tracks block objectives and mob rewards. */
public final class QuestGameplayListener implements Listener {
    private final SMPCore plugin;

    public QuestGameplayListener(SMPCore plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        plugin.onQuestBlockBreak(event);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        plugin.onQuestBlockPlace(event);
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        plugin.onMobReward(event);
    }
}
