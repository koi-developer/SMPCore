package me.ren.smpcore.quest;

import me.ren.smpcore.economy.EconomyManager;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Owns quest configuration reads, objective progress, readiness and reward claims.
 * All methods must be called on the server thread because Bukkit YAML configuration
 * and the economy persistence service are not thread-safe.
 */
public final class QuestManager {
    private static final Pattern SAFE_QUEST_KEY = Pattern.compile("[A-Za-z0-9_-]{1,48}");

    private final FileConfiguration config;
    private final YamlConfiguration playerData;
    private final EconomyManager economy;
    private final Runnable markDirty;

    public QuestManager(FileConfiguration config, YamlConfiguration playerData,
                        EconomyManager economy, Runnable markDirty) {
        if (config == null || playerData == null || economy == null) {
            throw new IllegalArgumentException("Quest manager dependencies must not be null.");
        }
        this.config = config;
        this.playerData = playerData;
        this.economy = economy;
        this.markDirty = markDirty == null ? () -> { } : markDirty;
    }

    public List<String> getEnabledQuestKeys() {
        if (!config.getBoolean("quests.enabled", true)) return List.of();
        ConfigurationSection root = config.getConfigurationSection("quests");
        if (root == null) return List.of();

        List<String> keys = new ArrayList<>();
        for (String key : root.getKeys(false)) {
            if (!isSafeKey(key)) continue;
            ConfigurationSection quest = root.getConfigurationSection(key);
            if (quest != null && quest.getBoolean("enabled", true)) keys.add(key);
        }
        keys.sort(String.CASE_INSENSITIVE_ORDER);
        return List.copyOf(keys);
    }

    public QuestView getQuest(UUID playerId, String key) {
        if (playerId == null || !isSafeKey(key) || !config.getBoolean("quests.enabled", true)) return null;
        ConfigurationSection quest = config.getConfigurationSection("quests." + key);
        if (quest == null || !quest.getBoolean("enabled", true)) return null;

        long target = Math.max(1L, quest.getLong("target", 1L));
        String base = playerPath(playerId, key);
        long progress = Math.min(target, Math.max(0L, playerData.getLong(base + ".progress", 0L)));
        long reward = Math.max(0L, quest.getLong("reward", 0L));
        String icon = quest.getString("icon", "BOOK");
        Material material = icon == null ? null : Material.matchMaterial(icon);
        if (material == null || !material.isItem()) material = Material.BOOK;

        return new QuestView(key,
                quest.getString("display-name", key),
                quest.getString("description", "Complete this objective."),
                quest.getString("type", ""), target, progress, reward,
                material, playerData.getBoolean(base + ".claimed", false));
    }

    public long countReady(UUID playerId) {
        if (playerId == null) return 0L;
        long count = 0L;
        for (String key : getEnabledQuestKeys()) {
            QuestView quest = getQuest(playerId, key);
            if (quest != null && !quest.claimed() && quest.progress() >= quest.target()) count++;
        }
        return count;
    }

    /**
     * Adds objective progress, capped at each configured target. Returns the display
     * names of quests which became ready during this update.
     */
    public List<String> incrementProgress(UUID playerId, String objectiveType, long amount) {
        if (playerId == null || objectiveType == null || objectiveType.isBlank() || amount <= 0L) return List.of();

        List<String> newlyReady = new ArrayList<>();
        boolean changed = false;
        for (String key : getEnabledQuestKeys()) {
            ConfigurationSection quest = config.getConfigurationSection("quests." + key);
            if (quest == null || !objectiveType.equalsIgnoreCase(quest.getString("type", ""))) continue;

            String path = playerPath(playerId, key);
            if (playerData.getBoolean(path + ".claimed", false)) continue;

            long target = Math.max(1L, quest.getLong("target", 1L));
            long current = Math.min(target, Math.max(0L, playerData.getLong(path + ".progress", 0L)));
            long remaining = target - current;
            long next = amount >= remaining ? target : current + amount;
            if (next == current) continue;

            playerData.set(path + ".progress", next);
            changed = true;
            if (current < target && next >= target) {
                newlyReady.add(quest.getString("display-name", key));
            }
        }

        if (changed) markDirty.run();
        return List.copyOf(newlyReady);
    }

    /**
     * Atomically marks a quest claimed and credits its reward in the same players.yml
     * write. The EconomyManager restores the in-memory YAML snapshot if persistence fails.
     */
    public ClaimResult claim(UUID playerId, String key) {
        if (playerId == null || !config.getBoolean("quests.enabled", true)
                || !config.getBoolean("economy.enabled", true)) {
            return new ClaimResult(ClaimStatus.DISABLED, key, "", 0L);
        }

        QuestView quest = getQuest(playerId, key);
        if (quest == null) return new ClaimResult(ClaimStatus.UNKNOWN_QUEST, key, "", 0L);
        if (quest.claimed()) return new ClaimResult(ClaimStatus.ALREADY_CLAIMED, key, quest.displayName(), 0L);
        if (quest.progress() < quest.target()) return new ClaimResult(ClaimStatus.INCOMPLETE, key, quest.displayName(), 0L);
        if (quest.reward() <= 0L) return new ClaimResult(ClaimStatus.INVALID_REWARD, key, quest.displayName(), 0L);

        long currentBalance = economy.getBalance(playerId);
        if (currentBalance > Long.MAX_VALUE - quest.reward()) {
            return new ClaimResult(ClaimStatus.WALLET_FULL, key, quest.displayName(), 0L);
        }

        final ClaimStatus[] status = {ClaimStatus.SAVE_FAILED};
        final long reward = quest.reward();
        final String base = playerPath(playerId, key);
        boolean saved = economy.updatePlayerSettings(data -> {
            if (data.getBoolean(base + ".claimed", false)) {
                status[0] = ClaimStatus.ALREADY_CLAIMED;
                return;
            }
            long target = Math.max(1L, config.getLong("quests." + key + ".target", 1L));
            long progress = Math.max(0L, data.getLong(base + ".progress", 0L));
            if (progress < target) {
                status[0] = ClaimStatus.INCOMPLETE;
                return;
            }
            String balancePath = "players." + playerId + ".balance";
            long balance = Math.max(0L, data.getLong(balancePath, currentBalance));
            if (balance > Long.MAX_VALUE - reward) {
                status[0] = ClaimStatus.WALLET_FULL;
                return;
            }
            data.set(balancePath, balance + reward);
            data.set(base + ".claimed", true);
            status[0] = ClaimStatus.CLAIMED;
        }, "quest reward");

        if (!saved && status[0] == ClaimStatus.CLAIMED) status[0] = ClaimStatus.SAVE_FAILED;
        if (status[0] != ClaimStatus.CLAIMED && saved) {
            // The mutation detected a stale state and intentionally made no changes.
            return new ClaimResult(status[0], key, quest.displayName(), 0L);
        }
        return new ClaimResult(status[0], key, quest.displayName(), status[0] == ClaimStatus.CLAIMED ? reward : 0L);
    }

    private static boolean isSafeKey(String key) {
        return key != null && SAFE_QUEST_KEY.matcher(key).matches();
    }

    private static String playerPath(UUID playerId, String key) {
        return "players." + playerId + ".quests." + key;
    }

    public record QuestView(String key, String displayName, String description, String type,
                            long target, long progress, long reward, Material icon, boolean claimed) { }

    public enum ClaimStatus {
        CLAIMED, DISABLED, UNKNOWN_QUEST, ALREADY_CLAIMED, INCOMPLETE,
        INVALID_REWARD, WALLET_FULL, SAVE_FAILED
    }

    public record ClaimResult(ClaimStatus status, String key, String displayName, long reward) { }
}
