package me.ren.smpcore.storage;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.UUID;
import java.util.function.Consumer;

/** Writes a file to a unique sibling temporary path before replacing its destination. */
public final class AtomicFileWriter {
    @FunctionalInterface
    public interface FileContentWriter {
        void write(Path temporaryFile) throws Exception;
    }

    private AtomicFileWriter() { }

    public static boolean write(Path destination, FileContentWriter writer, Consumer<String> errorLogger) {
        if (destination == null || writer == null) return false;
        Path temporary = null;
        try {
            Path parent = destination.toAbsolutePath().getParent();
            if (parent == null) throw new IOException("Destination has no parent directory.");
            Files.createDirectories(parent);
            String name = destination.getFileName().toString();
            temporary = parent.resolve("." + name + "." + UUID.randomUUID() + ".tmp");
            writer.write(temporary);
            if (!Files.isRegularFile(temporary)) throw new IOException("Writer did not create a regular temporary file.");
            try (FileChannel channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) {
                channel.force(true);
            }
            try {
                Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (Exception exception) {
            if (errorLogger != null) errorLogger.accept(exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage());
            return false;
        } finally {
            if (temporary != null) {
                try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
            }
        }
    }
}
