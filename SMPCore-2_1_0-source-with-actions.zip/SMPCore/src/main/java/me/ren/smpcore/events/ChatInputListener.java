package me.ren.smpcore.events;

import io.papermc.paper.event.player.AsyncChatEvent;
import me.ren.smpcore.SMPCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.Objects;

/** Captures chat replies for menu actions without running Bukkit mutations asynchronously. */
public final class ChatInputListener implements Listener {
    private final SMPCore plugin;

    public ChatInputListener(SMPCore plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChatInput(AsyncChatEvent event) {
        plugin.onChatInput(event);
    }
}
