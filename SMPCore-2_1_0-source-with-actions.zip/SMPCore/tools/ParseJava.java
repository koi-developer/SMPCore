import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import com.sun.source.util.JavacTask;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Parses all project sources with the JDK compiler front-end without resolving Paper dependencies. */
public final class ParseJava {
    private ParseJava() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Usage: ParseJava <source-root>");
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("A full JDK is required.");

        DiagnosticCollector<javax.tools.JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, null, null)) {
            List<Path> sources = new ArrayList<>();
            try (var paths = Files.walk(Path.of(args[0]))) {
                paths.filter(path -> path.toString().endsWith(".java")).forEach(sources::add);
            }
            var units = manager.getJavaFileObjectsFromPaths(sources);
            JavacTask task = (JavacTask) compiler.getTask(
                    null, manager, diagnostics, List.of("-proc:none", "--release", "21"), null, units);
            task.parse();

            boolean failed = false;
            for (Diagnostic<?> diagnostic : diagnostics.getDiagnostics()) {
                System.out.println(diagnostic);
                if (diagnostic.getKind() == Diagnostic.Kind.ERROR) failed = true;
            }
            if (failed) System.exit(1);
            System.out.println("Java syntax parse passed for " + sources.size() + " source files.");
        }
    }
}
