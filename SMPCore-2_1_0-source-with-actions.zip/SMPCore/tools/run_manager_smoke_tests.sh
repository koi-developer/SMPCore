#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT
find "$ROOT/tools/smoke-stubs" -name '*.java' -print > "$TMP_DIR/sources.txt"
printf '%s\n' \
  "$ROOT/src/main/java/me/ren/smpcore/economy/EconomyManager.java" \
  "$ROOT/src/main/java/me/ren/smpcore/quest/QuestManager.java" \
  "$ROOT/src/main/java/me/ren/smpcore/teleport/TeleportManager.java" \
  "$ROOT/tools/smoke/ManagerSmokeTest.java" >> "$TMP_DIR/sources.txt"
javac --release 21 -d "$TMP_DIR/classes" @"$TMP_DIR/sources.txt"
java -ea -cp "$TMP_DIR/classes" ManagerSmokeTest
