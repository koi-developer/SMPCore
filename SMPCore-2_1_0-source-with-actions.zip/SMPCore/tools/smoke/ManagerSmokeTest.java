import me.ren.smpcore.economy.EconomyManager;
import me.ren.smpcore.quest.QuestManager;
import me.ren.smpcore.teleport.TeleportManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class ManagerSmokeTest {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        System.out.println("PASS: " + message);
    }

    public static void main(String[] args) {
        testQuestManager();
        testTeleportManager();
        System.out.println("Manager smoke tests passed.");
    }

    private static void testQuestManager() {
        FileConfiguration config = new FileConfiguration();
        config.set("quests.enabled", true);
        config.set("economy.enabled", true);
        config.set("quests.gather.enabled", true);
        config.set("quests.gather.display-name", "Gatherer");
        config.set("quests.gather.description", "Collect items");
        config.set("quests.gather.type", "BLOCKS_BROKEN");
        config.set("quests.gather.target", 5L);
        config.set("quests.gather.reward", 25L);
        config.set("quests.gather.icon", "BOOK");
        config.set("quests.disabled.enabled", false);
        config.set("quests.playtime.enabled", true);
        config.set("quests.playtime.type", "PLAYTIME_SECONDS");
        config.set("quests.playtime.target", 2L);
        config.set("quests.playtime.reward", 10L);

        YamlConfiguration playerData = new YamlConfiguration();
        AtomicBoolean saveAllowed = new AtomicBoolean(true);
        AtomicInteger dirtyMarks = new AtomicInteger();
        EconomyManager economy = new EconomyManager(playerData, () -> 100L,
                saveAllowed::get, dirtyMarks::incrementAndGet, ignored -> { });
        QuestManager quests = new QuestManager(config, playerData, economy, dirtyMarks::incrementAndGet);
        UUID playerId = UUID.randomUUID();

        check(quests.getEnabledQuestKeys().equals(java.util.List.of("gather", "playtime")),
                "quest keys are filtered and sorted");
        check(quests.incrementProgress(playerId, "BLOCKS_BROKEN", 3L).isEmpty(),
                "partial objective progress does not announce readiness");
        check(quests.incrementProgress(playerId, "BLOCKS_BROKEN", 2L).equals(java.util.List.of("Gatherer")),
                "objective completion is detected once");
        check(quests.countReady(playerId) == 1L, "ready quest count reflects stored progress");

        QuestManager.ClaimResult claimed = quests.claim(playerId, "gather");
        check(claimed.status() == QuestManager.ClaimStatus.CLAIMED && claimed.reward() == 25L,
                "quest claim reports successful reward");
        check(economy.getBalance(playerId) == 125L, "quest reward and wallet are committed together");
        check(quests.claim(playerId, "gather").status() == QuestManager.ClaimStatus.ALREADY_CLAIMED,
                "quest reward cannot be claimed twice");
        check(quests.getQuest(playerId, "../unsafe") == null,
                "unsafe quest keys are rejected");

        config.set("quests.large.target", Long.MAX_VALUE);
        config.set("quests.large.type", "LARGE_COUNTER");
        config.set("quests.large.reward", 1L);
        config.set("quests.large.enabled", true);
        UUID largePlayer = UUID.randomUUID();
        quests.incrementProgress(largePlayer, "LARGE_COUNTER", Long.MAX_VALUE);
        check(playerData.getLong("players." + largePlayer + ".quests.large.progress", 0L) == Long.MAX_VALUE,
                "large objective progress caps without numeric overflow");

        UUID secondPlayer = UUID.randomUUID();
        quests.incrementProgress(secondPlayer, "PLAYTIME_SECONDS", 2L);
        saveAllowed.set(false);
        QuestManager.ClaimResult failed = quests.claim(secondPlayer, "playtime");
        check(failed.status() == QuestManager.ClaimStatus.SAVE_FAILED,
                "failed persistence returns a clear claim failure");
        check(!playerData.getBoolean("players." + secondPlayer + ".quests.playtime.claimed", false),
                "failed quest claim restores the unclaimed state");
        check(economy.getBalance(secondPlayer) == 100L,
                "failed quest claim does not retain a credited reward");
    }

    private static void testTeleportManager() {
        World world = new World("world");
        Bukkit.registerWorld(world);
        YamlConfiguration homes = new YamlConfiguration();
        YamlConfiguration warps = new YamlConfiguration();
        AtomicBoolean homeSave = new AtomicBoolean(true);
        AtomicBoolean warpSave = new AtomicBoolean(true);
        TeleportManager manager = new TeleportManager(homes, warps,
                homeSave::get, warpSave::get, ignored -> { });
        UUID owner = UUID.randomUUID();
        Location destination = new Location(world, 12.5, 70.0, -8.25, 45.0f, 5.0f);

        check(manager.createHome(owner, "Base", destination), "home creation persists successfully");
        check(manager.getHomeNames(owner).equals(java.util.List.of("base")), "home names are normalized and sorted");
        check(manager.getHome(owner, "BASE") != null, "home lookup is case-insensitive");
        check(!manager.createHome(owner, "base", destination), "duplicate home creation is rejected");

        check(manager.createWarp("Market", destination), "warp creation persists successfully");
        check(manager.getWarpNames().equals(java.util.List.of("market")), "warp names are normalized");
        check(!manager.createWarp("market", destination), "duplicate warp creation is rejected");
        warpSave.set(false);
        check(!manager.deleteWarp("market"), "failed warp deletion reports failure");
        check(manager.getWarp("market") != null, "failed warp deletion restores the listing in memory");
        check(!manager.createWarp("failed", destination), "failed warp creation reports failure");
        check(manager.getWarp("failed") == null, "failed warp creation rolls back its in-memory entry");

        homes.set("homes." + owner + ".broken.world", "world");
        homes.set("homes." + owner + ".broken.x", Double.NaN);
        homes.set("homes." + owner + ".broken.y", 64.0D);
        homes.set("homes." + owner + ".broken.z", 0.0D);
        check(manager.getHome(owner, "broken") == null,
                "stored destinations with non-finite coordinates are rejected");

        Player player = new Player(new Location(world, 0, 64, 0, 0, 0));
        check(manager.teleport(player, destination) == TeleportManager.TeleportResult.SUCCESS,
                "teleport succeeds for a loaded in-border destination");
        world.getWorldBorder().setInside(false);
        check(manager.teleport(player, destination) == TeleportManager.TeleportResult.OUTSIDE_BORDER,
                "teleport rejects destinations outside the world border");
        check(manager.teleport(player, new Location(world, Double.NaN, 64, 0, 0, 0))
                        == TeleportManager.TeleportResult.UNAVAILABLE,
                "teleport rejects malformed non-finite destinations");
        world.getWorldBorder().setInside(true);
        player.setTeleportAllowed(false);
        check(manager.teleport(player, destination) == TeleportManager.TeleportResult.CANCELLED,
                "teleport reports a cancelled Bukkit teleport separately");
        homeSave.set(false);
        check(!manager.deleteHome(owner, "base"), "failed home deletion reports failure");
        check(manager.getHome(owner, "base") != null, "failed home deletion restores the home in memory");
    }
}
