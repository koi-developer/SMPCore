#!/usr/bin/env python3
"""Offline structural checks for an SMPCore source release."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

try:
    import yaml
except ImportError:
    yaml = None

ROOT = Path(__file__).resolve().parents[1]
POM = ROOT / "pom.xml"
PLUGIN_YML = ROOT / "src/main/resources/plugin.yml"
CONFIG_YML = ROOT / "src/main/resources/config.yml"
MAIN = ROOT / "src/main/java/me/ren/smpcore/SMPCore.java"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"FAIL: {message}")
    print(f"PASS: {message}")


def main() -> None:
    pom = ET.parse(POM).getroot()
    ns = {"m": "http://maven.apache.org/POM/4.0.0"}
    version = pom.findtext("m:version", namespaces=ns)
    final_name = pom.findtext("m:build/m:finalName", namespaces=ns)
    java_release = pom.findtext("m:properties/m:maven.compiler.release", namespaces=ns)
    paper_version = pom.findtext(
        "m:dependencies/m:dependency[m:artifactId='paper-api']/m:version", namespaces=ns
    )
    require(version == "2.1.0", "Maven project version is 2.1.0")
    require(final_name == f"SMPCore-{version}", "JAR final name matches release version")
    require(java_release == "21", "Java compiler release remains 21")
    require(paper_version == "1.21.11-R0.1-SNAPSHOT", "Paper API dependency targets 1.21.11")

    plugin_text = PLUGIN_YML.read_text(encoding="utf-8")
    require(f"version: {version}" in plugin_text, "plugin.yml version matches release")
    require("api-version: '1.21'" in plugin_text, "plugin.yml API metadata remains 1.21")

    main_text = MAIN.read_text(encoding="utf-8")
    require("extends JavaPlugin {" in main_text, "main class is the JavaPlugin lifecycle entry point")
    require("implements Listener" not in main_text and "implements Listener," not in main_text,
            "main class no longer implements Listener")
    require("implements CommandExecutor" not in main_text,
            "main class no longer implements CommandExecutor")
    require("@EventHandler" not in main_text,
            "event annotations have moved out of the main class")

    required_files = [
        "src/main/java/me/ren/smpcore/commands/MenuCommand.java",
        "src/main/java/me/ren/smpcore/events/InventoryMenuListener.java",
        "src/main/java/me/ren/smpcore/events/ChatInputListener.java",
        "src/main/java/me/ren/smpcore/events/QuestGameplayListener.java",
        "src/main/java/me/ren/smpcore/events/PlayerLifecycleListener.java",
        "src/main/java/me/ren/smpcore/quest/QuestManager.java",
        "src/main/java/me/ren/smpcore/teleport/TeleportManager.java",
    ]
    for relative in required_files:
        require((ROOT / relative).is_file(), f"module exists: {relative}")

    require("new MenuCommand(this)" in main_text, "menu command adapter is registered")
    for adapter in ["InventoryMenuListener", "ChatInputListener", "QuestGameplayListener", "PlayerLifecycleListener"]:
        require(f"new {adapter}(this)" in main_text, f"listener is registered: {adapter}")
    require("new QuestManager(getConfig(), playerSettings, economyManager" in main_text,
            "QuestManager is wired during startup")
    require("new TeleportManager(homes, warps" in main_text,
            "TeleportManager is wired during startup")
    require("questManager.claim(player.getUniqueId(), key)" in main_text,
            "quest reward claims delegate to QuestManager")
    require("teleportManager.deleteHome(player.getUniqueId(), name)" in main_text,
            "home deletion delegates to TeleportManager")

    if yaml is not None:
        for path in (PLUGIN_YML, CONFIG_YML):
            with path.open(encoding="utf-8") as stream:
                parsed = yaml.safe_load(stream)
            require(isinstance(parsed, dict), f"YAML parses as a mapping: {path.name}")
    else:
        print("SKIP: PyYAML is not installed; YAML syntax check unavailable.")

    archive = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if archive:
        with zipfile.ZipFile(archive) as bundle:
            bad = bundle.testzip()
            require(bad is None, "release ZIP CRC/integrity check passed")
            names = set(bundle.namelist())
            require("SMPCore/pom.xml" in names, "release ZIP contains Maven project")
            require(any(name.endswith("MenuCommand.java") for name in names),
                    "release ZIP contains command adapter")
            require(any(name.endswith("QuestManager.java") for name in names),
                    "release ZIP contains QuestManager")
            require(any(name.endswith("TeleportManager.java") for name in names),
                    "release ZIP contains TeleportManager")
    print("Offline source validation completed. This does not compile the plugin against Paper API.")


if __name__ == "__main__":
    main()
