package org.bukkit;

public class Location implements Cloneable {
    private final World world;
    private final double x, y, z;
    private final float yaw, pitch;
    public Location(World world, double x, double y, double z, float yaw, float pitch) {
        this.world = world; this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch;
    }
    public World getWorld() { return world; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }
    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    @Override public Location clone() { return new Location(world, x, y, z, yaw, pitch); }
}
