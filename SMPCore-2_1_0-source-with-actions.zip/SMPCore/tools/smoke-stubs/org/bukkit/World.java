package org.bukkit;

public class World {
    private final String name;
    private final WorldBorder border = new WorldBorder();
    public World(String name) { this.name = name; }
    public String getName() { return name; }
    public WorldBorder getWorldBorder() { return border; }
}
