package org.bukkit;

public enum Material {
    AIR(false), BOOK(true), BREAD(true), STONE(true);
    private final boolean item;
    Material(boolean item) { this.item = item; }
    public boolean isItem() { return item; }
    public static Material matchMaterial(String name) {
        if (name == null) return null;
        try { return valueOf(name.trim().toUpperCase(java.util.Locale.ROOT)); }
        catch (IllegalArgumentException ignored) { return null; }
    }
}
