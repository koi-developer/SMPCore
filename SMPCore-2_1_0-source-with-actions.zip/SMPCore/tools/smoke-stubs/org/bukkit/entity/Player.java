package org.bukkit.entity;

import org.bukkit.Location;

public class Player {
    private Location location;
    private boolean teleportAllowed = true;
    public Player(Location location) { this.location = location; }
    public boolean teleport(Location destination) {
        if (!teleportAllowed) return false;
        location = destination.clone();
        return true;
    }
    public Location getLocation() { return location; }
    public void setTeleportAllowed(boolean allowed) { teleportAllowed = allowed; }
}
