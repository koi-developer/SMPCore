package org.bukkit;

public class WorldBorder {
    private boolean inside = true;
    public boolean isInside(Location location) { return inside; }
    public void setInside(boolean inside) { this.inside = inside; }
}
