package org.bukkit.configuration.file;

import org.bukkit.configuration.InvalidConfigurationException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

public class YamlConfiguration extends FileConfiguration {
    public String saveToString() {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (ObjectOutputStream output = new ObjectOutputStream(bytes)) { output.writeObject(new LinkedHashMap<>(values)); }
            return Base64.getEncoder().encodeToString(bytes.toByteArray());
        } catch (Exception exception) { throw new IllegalStateException(exception); }
    }
    @SuppressWarnings("unchecked")
    public void loadFromString(String encoded) throws InvalidConfigurationException {
        try {
            byte[] bytes = Base64.getDecoder().decode(encoded);
            try (ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
                Object restored = input.readObject();
                values.clear();
                values.putAll((Map<String, Object>) restored);
            }
        } catch (Exception exception) { throw new InvalidConfigurationException(exception.getMessage()); }
    }
}
