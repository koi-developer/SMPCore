package org.bukkit.configuration;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class ConfigurationSection {
    protected final Map<String, Object> values;
    protected final String prefix;
    public ConfigurationSection() { this(new LinkedHashMap<>(), ""); }
    protected ConfigurationSection(Map<String, Object> values, String prefix) {
        this.values = values;
        this.prefix = prefix;
    }
    protected String key(String path) { return prefix.isEmpty() ? path : prefix + "." + path; }
    public void set(String path, Object value) {
        String full = key(path);
        if (value == null) values.keySet().removeIf(k -> k.equals(full) || k.startsWith(full + "."));
        else values.put(full, value);
    }
    public boolean contains(String path) { return values.containsKey(key(path)) || isConfigurationSection(path); }
    public boolean isConfigurationSection(String path) {
        String full = key(path) + ".";
        return values.keySet().stream().anyMatch(k -> k.startsWith(full));
    }
    public ConfigurationSection getConfigurationSection(String path) {
        if (!isConfigurationSection(path)) return null;
        return new ConfigurationSection(values, key(path));
    }
    public Set<String> getKeys(boolean deep) {
        String base = prefix.isEmpty() ? "" : prefix + ".";
        Set<String> result = new LinkedHashSet<>();
        for (String stored : values.keySet()) {
            if (!stored.startsWith(base)) continue;
            String remainder = stored.substring(base.length());
            if (remainder.isEmpty()) continue;
            if (!deep && remainder.contains(".")) remainder = remainder.substring(0, remainder.indexOf('.'));
            result.add(remainder);
        }
        return result;
    }
    public boolean getBoolean(String path, boolean fallback) {
        Object value = values.get(key(path));
        return value instanceof Boolean b ? b : fallback;
    }
    public long getLong(String path, long fallback) {
        Object value = values.get(key(path));
        return value instanceof Number n ? n.longValue() : fallback;
    }
    public double getDouble(String path, double fallback) {
        Object value = values.get(key(path));
        return value instanceof Number n ? n.doubleValue() : fallback;
    }
    public String getString(String path, String fallback) {
        Object value = values.get(key(path));
        return value == null ? fallback : String.valueOf(value);
    }
    public String getString(String path) { return getString(path, null); }
}
