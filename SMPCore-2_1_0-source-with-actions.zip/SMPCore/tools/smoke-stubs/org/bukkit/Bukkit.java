package org.bukkit;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Bukkit {
    private static final Map<String, World> WORLDS = new ConcurrentHashMap<>();
    private Bukkit() { }
    public static World getWorld(String name) { return name == null ? null : WORLDS.get(name); }
    public static void registerWorld(World world) { WORLDS.put(world.getName(), world); }
}
