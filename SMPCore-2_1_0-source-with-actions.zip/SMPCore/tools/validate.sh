#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT
javac --release 21 -d "$TMP_DIR" "$ROOT/tools/ParseJava.java"
java -cp "$TMP_DIR" ParseJava "$ROOT/src/main/java"
python3 "$ROOT/tools/validate_source.py"
sh "$ROOT/tools/run_manager_smoke_tests.sh"
