# Changelog

## 2.1.0
- Extracted quest configuration, objective progress, ready-state counting and atomic reward claims into `QuestManager`.
- Quest claims now commit the reward balance and claimed flag through the same `EconomyManager.updatePlayerSettings` write; failed persistence restores the previous in-memory YAML snapshot.
- Quest definitions are filtered to safe keys, sorted and exposed as immutable views; objective progress is capped safely without numeric overflow.
- Extracted home/warp lookup, creation, deletion, location parsing and teleport guards into `TeleportManager`.
- Home and warp create/delete operations now share one snapshot-save-rollback path; rollback failures are explicitly logged.
- Rejects malformed non-finite stored coordinates/rotations and teleport destinations outside the world's border.
- Rebuilds `QuestManager` after Admin Panel config reload so it uses the refreshed `FileConfiguration` instance.
- Added isolated Java 21 manager smoke tests for quest rewards, duplicate claims, failed-save rollback, home/warp persistence and teleport validation.
- Preserved `/menu`, `/smpmenu`, Paper 1.21.11 / Java 21 and the existing `players.yml`, `homes.yml` and `warps.yml` data paths.

## 2.0.0
- Added a dedicated `MenuCommand` adapter; `SMPCore` is no longer coupled to Bukkit's `CommandExecutor` interface.
- Extracted InventoryClick/InventoryDrag handling into `InventoryMenuListener`.
- Extracted Paper `AsyncChatEvent` registration into `ChatInputListener`; the existing main-thread handoff remains in the workflow method.
- Extracted block progression and mob reward registrations into `QuestGameplayListener`.
- Extracted player death/join/quit registrations into `PlayerLifecycleListener`.
- Registered and unregisters all event adapters through `EventManager`; listener identity tracking prevents accidental duplicate instance registration.
- Hardened `PlayerManager` path validation, malformed stat-key handling, immutable player-ID snapshots, and statistic overflow checks.
- Preserved `/menu`, `/smpmenu`, Paper 1.21.11 / Java 21, and existing YAML data paths.

## 1.9.0
- Extracted inventory creation, per-viewer menu session metadata, and menu frame rendering into `MenuManager`.
- Added `PlayerManager` for player identity, preferences, statistics, and playtime formatting while preserving the existing `players.yml` paths.
- Added `EventManager` to centralize listener registration and deterministic teardown.
- Corrected `plugin.yml` `api-version` to `1.21` while keeping the Maven API dependency at `1.21.11-R0.1-SNAPSHOT`.
- Preserved `/menu`, `/smpmenu`, existing GUI page identifiers, and existing data-file layouts.
